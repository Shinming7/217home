// 217之家 · 客厅麻将
// 108 张数牌（万/条/筒 各 1-9 四张）的简化推倒胡：可吃、碰、明杠、暗杠、补杠，
// 自摸与点炮都能胡，胡牌算番（平胡 1 分，门清/碰碰胡/清一色/七对各 +1）。
// 纯状态机：时间由调用方传入，随机只出现在洗牌，方便单测与回放。

export type MahjongPhase = "waiting" | "playing" | "result";

export type MahjongMeldKind = "chi" | "peng" | "gang" | "angang";

export type MahjongMeld = {
  kind: MahjongMeldKind;
  tiles: string[];
  /** 吃/碰/明杠来自哪一位打出，暗杠为 null */
  from: number | null;
};

export type MahjongSeat = {
  memberId: string;
  nickname: string;
  hand: string[];
  melds: MahjongMeld[];
  discards: string[];
  score: number;
  lastAction: string;
};

export type MahjongClaimOption = {
  hu: boolean;
  gang: boolean;
  peng: boolean;
  /** 每种吃法需要的两张手牌，与打出的牌组成顺子 */
  chi: string[][];
};

export type MahjongClaim = {
  tile: string;
  from: number;
  deadline: number;
  options: Record<string, MahjongClaimOption>;
  /** memberId -> null（还没决定）/ "hu" / "gang" / "peng" / "pass" / "chi:1m,2m" */
  responses: Record<string, string | null>;
};

export type MahjongResult = {
  draw: boolean;
  winnerSeat: number | null;
  winnerName: string | null;
  fromSeat: number | null;
  fromName: string | null;
  tile: string | null;
  selfDraw: boolean;
  fans: string[];
  points: number;
  text: string;
  hand: string[];
  melds: MahjongMeld[];
};

export type MahjongState = {
  mode: MahjongMode;
  phase: MahjongPhase;
  handNo: number;
  dealer: number;
  turn: number;
  wall: string[];
  seats: (MahjongSeat | null)[];
  /** 当前行动者刚摸到的牌（也是他手里多出来的那张） */
  drawn: string | null;
  justDrew: boolean;
  lastDiscard: { seat: number; tile: string } | null;
  claim: MahjongClaim | null;
  deadline: number;
  result: MahjongResult | null;
  logs: string[];
  updatedAt: number;
};

export class MahjongError extends Error {
  code: string;

  constructor(code: string) {
    super(code);
    this.name = "MahjongError";
    this.code = code;
  }
}

export const MAHJONG_SEATS = 4;
export const START_SCORE = 1000;
export const TURN_MS = 30_000;
export const CLAIM_MS = 8_000;
export const RESULT_MS = 11_000;
const LOG_LIMIT = 14;

const SUITS = ["m", "s", "p"] as const;
export const SUIT_LABEL: Record<string, string> = { m: "万", s: "条", p: "筒" };

export type MahjongMode = "classic" | "nochi" | "honors";

export type MahjongModeSpec = {
  id: MahjongMode;
  name: string;
  desc: string;
  allowChi: boolean;
  honors: boolean;
};

export const MAHJONG_MODES: MahjongModeSpec[] = [
  { id: "classic", name: "经典", desc: "108 张数牌，可吃可碰，按番型结算", allowChi: true, honors: false },
  { id: "nochi", name: "不吃", desc: "108 张数牌，只能碰杠，节奏更快", allowChi: false, honors: false },
  { id: "honors", name: "带字牌", desc: "136 张，加入东南西北中发白", allowChi: true, honors: true },
];

const HONOR_TILES = ["1z", "2z", "3z", "4z", "5z", "6z", "7z"] as const;
export const HONOR_LABEL: Record<string, string> = {
  "1z": "东",
  "2z": "南",
  "3z": "西",
  "4z": "北",
  "5z": "中",
  "6z": "发",
  "7z": "白",
};

export function isMahjongMode(value: unknown): value is MahjongMode {
  return value === "classic" || value === "nochi" || value === "honors";
}

export function modeSpec(mode: MahjongMode): MahjongModeSpec {
  return MAHJONG_MODES.find((item) => item.id === mode) ?? MAHJONG_MODES[0];
}

export function tileName(tile: string): string {
  if (!tile) return "";
  if (tile[1] === "z") return HONOR_LABEL[tile] ?? "字";
  return `${tile[0]}${SUIT_LABEL[tile[1]] ?? tile[1]}`;
}

function tileIndex(tile: string): number {
  const number = Number(tile[0]);
  if (tile[1] === "z") return 27 + (number - 1);
  const suit = SUITS.indexOf(tile[1] as (typeof SUITS)[number]);
  return suit * 9 + (number - 1);
}

function tileOfIndex(index: number): string {
  if (index >= 27) return `${index - 26}z`;
  return `${(index % 9) + 1}${SUITS[Math.floor(index / 9)]}`;
}

export function sortTiles(tiles: string[]): string[] {
  return [...tiles].sort((left, right) => tileIndex(left) - tileIndex(right));
}

function countsOf(tiles: string[]): number[] {
  const counts = new Array(34).fill(0) as number[];
  for (const tile of tiles) {
    const index = tileIndex(tile);
    if (index >= 0 && index < 34) counts[index] += 1;
  }
  return counts;
}

function shuffledWall(honors: boolean): string[] {
  const wall: string[] = [];
  for (const suit of SUITS) {
    for (let number = 1; number <= 9; number += 1) {
      for (let copy = 0; copy < 4; copy += 1) wall.push(`${number}${suit}`);
    }
  }
  if (honors) {
    for (const tile of HONOR_TILES) {
      for (let copy = 0; copy < 4; copy += 1) wall.push(tile);
    }
  }
  for (let index = wall.length - 1; index > 0; index -= 1) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    const swap = buffer[0] % (index + 1);
    [wall[index], wall[swap]] = [wall[swap], wall[index]];
  }
  return wall;
}

function pushLog(state: MahjongState, text: string) {
  state.logs.push(text);
  if (state.logs.length > LOG_LIMIT) state.logs = state.logs.slice(-LOG_LIMIT);
}

export function createTable(mode: MahjongMode = "classic"): MahjongState {
  return {
    mode,
    phase: "waiting",
    handNo: 0,
    dealer: -1,
    turn: -1,
    wall: [],
    seats: Array.from({ length: MAHJONG_SEATS }, () => null),
    drawn: null,
    justDrew: false,
    lastDiscard: null,
    claim: null,
    deadline: 0,
    result: null,
    logs: ["客厅的麻将桌已经摆好，凑齐 4 位住户就自动开局。"],
    updatedAt: Date.now(),
  };
}

function seatIndex(state: MahjongState, memberId: string): number {
  return state.seats.findIndex((seat) => seat?.memberId === memberId);
}

function requireSeat(state: MahjongState, memberId: string): { index: number; seat: MahjongSeat } {
  const index = seatIndex(state, memberId);
  if (index < 0) throw new MahjongError("not_seated");
  return { index, seat: state.seats[index]! };
}

function seatedCount(state: MahjongState): number {
  return state.seats.filter((seat) => seat !== null).length;
}

function removeOne(hand: string[], tile: string): void {
  const at = hand.indexOf(tile);
  if (at < 0) throw new MahjongError("invalid_tile");
  hand.splice(at, 1);
}

/* ---------------- 胡牌判断 ---------------- */

function canFormSets(counts: number[], need: number): boolean {
  if (need === 0) return counts.every((count) => count === 0);
  let first = -1;
  for (let index = 0; index < counts.length; index += 1) {
    if (counts[index] > 0) {
      first = index;
      break;
    }
  }
  if (first < 0) return false;
  if (counts[first] >= 3) {
    counts[first] -= 3;
    const ok = canFormSets(counts, need - 1);
    counts[first] += 3;
    if (ok) return true;
  }
  const number = first % 9;
  if (first < 27 && number <= 6 && counts[first + 1] > 0 && counts[first + 2] > 0) {
    counts[first] -= 1;
    counts[first + 1] -= 1;
    counts[first + 2] -= 1;
    const ok = canFormSets(counts, need - 1);
    counts[first] += 1;
    counts[first + 1] += 1;
    counts[first + 2] += 1;
    if (ok) return true;
  }
  return false;
}

function isStandardWin(hand: string[], melds: MahjongMeld[]): boolean {
  if (hand.length !== 14 - melds.length * 3) return false;
  const need = (hand.length - 2) / 3;
  if (!Number.isInteger(need) || need !== 4 - melds.length) return false;
  const counts = countsOf(hand);
  for (let index = 0; index < counts.length; index += 1) {
    if (counts[index] < 2) continue;
    counts[index] -= 2;
    const ok = canFormSets(counts, need);
    counts[index] += 2;
    if (ok) return true;
  }
  return false;
}

function isSevenPairs(hand: string[], melds: MahjongMeld[]): boolean {
  if (melds.length > 0 || hand.length !== 14) return false;
  const counts = countsOf(hand);
  let pairs = 0;
  for (const count of counts) {
    if (count === 0) continue;
    if (count !== 2 && count !== 4) return false;
    pairs += count / 2;
  }
  return pairs === 7;
}

function isAllTriplets(hand: string[], melds: MahjongMeld[]): boolean {
  if (melds.some((meld) => meld.kind === "chi")) return false;
  const counts = countsOf(hand);
  let pairs = 0;
  let triplets = 0;
  for (const count of counts) {
    if (count === 0) continue;
    if (count === 2) pairs += 1;
    else if (count === 3) triplets += 1;
    else return false;
  }
  if (pairs !== 1) return false;
  return triplets + melds.length === 4;
}

function isPureSuit(hand: string[], melds: MahjongMeld[]): boolean {
  const suits = new Set<string>();
  for (const tile of hand) suits.add(tile[1]);
  for (const meld of melds) for (const tile of meld.tiles) suits.add(tile[1]);
  return suits.size === 1 && !suits.has("z");
}

export type MahjongWin = { fans: string[]; points: number };

export function evaluateWin(hand: string[], melds: MahjongMeld[]): MahjongWin | null {
  const sevenPairs = isSevenPairs(hand, melds);
  const standard = isStandardWin(hand, melds);
  if (!sevenPairs && !standard) return null;
  const fans: string[] = [];
  if (sevenPairs) fans.push("七对");
  if (melds.every((meld) => meld.kind === "angang")) {
    fans.push("门清");
  }
  if (!sevenPairs && isAllTriplets(hand, melds)) fans.push("碰碰胡");
  if (isPureSuit(hand, melds)) fans.push("清一色");
  return { fans, points: 1 + fans.length };
}

/* ---------------- 开局与发牌 ---------------- */

export function joinTable(state: MahjongState, memberId: string, nickname: string, now: number) {
  if (seatIndex(state, memberId) >= 0) return;
  const free = state.seats.findIndex((seat) => seat === null);
  if (free < 0) throw new MahjongError("table_full");
  state.seats[free] = {
    memberId,
    nickname,
    hand: [],
    melds: [],
    discards: [],
    score: START_SCORE,
    lastAction: "刚坐下",
  };
  pushLog(state, `${nickname} 在 ${free + 1} 号位坐下`);
  state.updatedAt = now;
  if (state.phase === "waiting" && seatedCount(state) === MAHJONG_SEATS) startHand(state, now);
}

export function leaveTable(state: MahjongState, memberId: string, now: number) {
  const { seat } = requireSeat(state, memberId);
  const playing = state.phase === "playing";
  if (playing) {
    // 三缺一没法继续：这一局作废，不结算
    pushLog(state, `${seat.nickname} 起身离开，这一局作废`);
    state.phase = "waiting";
    state.turn = -1;
    state.claim = null;
    state.drawn = null;
    state.justDrew = false;
    state.lastDiscard = null;
    state.deadline = 0;
    state.result = null;
    state.wall = [];
    for (const other of state.seats) {
      if (!other) continue;
      other.hand = [];
      other.melds = [];
      other.lastAction = "等人齐";
    }
  }
  state.seats = state.seats.map((candidate) => (candidate?.memberId === memberId ? null : candidate));
  pushLog(state, `${seat.nickname} 离开了麻将桌`);
  state.updatedAt = now;
  if (seatedCount(state) === 0) {
    // 最后一个人走了：把桌子收拾干净，下次进来是新的
    Object.assign(state, createTable());
    return;
  }
  if (state.phase === "waiting") {
    state.deadline = 0;
    state.turn = -1;
  }
}

export function setMode(state: MahjongState, memberId: string, mode: string, now: number) {
  requireSeat(state, memberId);
  if (!isMahjongMode(mode)) throw new MahjongError("invalid_mode");
  if (state.phase === "playing") throw new MahjongError("hand_in_progress");
  if (state.mode === mode) return;
  state.mode = mode;
  state.updatedAt = now;
  pushLog(state, `玩法切到「${modeSpec(mode).name}」：${modeSpec(mode).desc}`);
}

export function startNextHand(state: MahjongState, memberId: string, now: number) {
  requireSeat(state, memberId);
  if (state.phase === "playing") throw new MahjongError("hand_in_progress");
  if (seatedCount(state) < MAHJONG_SEATS) throw new MahjongError("need_four_players");
  startHand(state, now);
}

function startHand(state: MahjongState, now: number) {
  if (seatedCount(state) < MAHJONG_SEATS) throw new MahjongError("need_four_players");
  state.handNo += 1;
  state.wall = shuffledWall(modeSpec(state.mode).honors);
  state.claim = null;
  state.result = null;
  state.lastDiscard = null;
  state.drawn = null;
  state.justDrew = false;
  for (const seat of state.seats) {
    if (!seat) continue;
    const hand: string[] = [];
    for (let index = 0; index < 13; index += 1) {
      const tile = state.wall.pop();
      if (tile) hand.push(tile);
    }
    seat.hand = sortTiles(hand);
    seat.melds = [];
    seat.discards = [];
    seat.lastAction = "起手";
  }
  if (state.dealer < 0 || !state.seats[state.dealer]) {
    // 庄家还没定，或者庄家已经走了：顺延到第一个有人的位置
    const next = state.seats.findIndex((seat) => seat !== null);
    state.dealer = next;
  }
  state.turn = state.dealer;
  const dealer = state.seats[state.dealer]!;
  const first = state.wall.pop();
  if (first) {
    dealer.hand.push(first);
    dealer.hand = sortTiles(dealer.hand);
    state.drawn = first;
    state.justDrew = true;
  }
  dealer.lastAction = "摸牌";
  state.phase = "playing";
  state.deadline = now + TURN_MS;
  state.updatedAt = now;
  pushLog(state, `第 ${state.handNo} 局开始，${dealer.nickname} 坐庄`);
}

function drawTile(state: MahjongState, index: number, now: number): boolean {
  const seat = state.seats[index];
  if (!seat) return false;
  if (!state.wall.length) {
    finishDraw(state, now);
    return false;
  }
  const tile = state.wall.pop()!;
  seat.hand.push(tile);
  seat.hand = sortTiles(seat.hand);
  state.drawn = tile;
  state.justDrew = true;
  state.turn = index;
  state.claim = null;
  state.deadline = now + TURN_MS;
  seat.lastAction = "摸牌";
  state.updatedAt = now;
  pushLog(state, `${seat.nickname} 摸牌（牌墙还剩 ${state.wall.length} 张）`);
  return true;
}

/* ---------------- 出牌与吃碰杠 ---------------- */

function claimOptionsFor(
  seat: MahjongSeat,
  tile: string,
  from: number,
  seatIndexValue: number,
  allowChi: boolean,
): MahjongClaimOption | null {
  const canMeld = seat.melds.length < 4;
  const copies = seat.hand.filter((handTile) => handTile === tile).length;
  const hu = evaluateWin(sortTiles([...seat.hand, tile]), seat.melds) !== null;
  const gang = canMeld && copies === 3;
  const peng = canMeld && copies >= 2;
  const chi: string[][] = [];
  if (canMeld && allowChi && tile[1] !== "z" && seatIndexValue === (from + 1) % MAHJONG_SEATS) {
    const number = Number(tile[0]);
    const suit = tile[1];
    const has = (value: number) => value >= 1 && value <= 9 && seat.hand.includes(`${value}${suit}`);
    if (has(number - 2) && has(number - 1)) chi.push([`${number - 2}${suit}`, `${number - 1}${suit}`]);
    if (has(number - 1) && has(number + 1)) chi.push([`${number - 1}${suit}`, `${number + 1}${suit}`]);
    if (has(number + 1) && has(number + 2)) chi.push([`${number + 1}${suit}`, `${number + 2}${suit}`]);
  }
  if (!hu && !gang && !peng && !chi.length) return null;
  return { hu, gang, peng, chi };
}

function takeDiscard(state: MahjongState, from: number, tile: string) {
  const seat = state.seats[from];
  if (!seat) return;
  const at = seat.discards.lastIndexOf(tile);
  if (at >= 0) seat.discards.splice(at, 1);
}

function openClaims(state: MahjongState, from: number, tile: string, now: number) {
  const options: Record<string, MahjongClaimOption> = {};
  for (let offset = 1; offset < MAHJONG_SEATS; offset += 1) {
    const index = (from + offset) % MAHJONG_SEATS;
    const seat = state.seats[index];
    if (!seat) continue;
    const option = claimOptionsFor(seat, tile, from, index, modeSpec(state.mode).allowChi);
    if (option) options[seat.memberId] = option;
  }
  if (!Object.keys(options).length) {
    const next = (from + 1) % MAHJONG_SEATS;
    state.turn = -1;
    drawTile(state, next, now);
    return;
  }
  const responses: Record<string, string | null> = {};
  for (const memberId of Object.keys(options)) responses[memberId] = null;
  state.claim = { tile, from, deadline: now + CLAIM_MS, options, responses };
  state.turn = -1;
  state.deadline = now + CLAIM_MS;
  state.updatedAt = now;
  const waiting = Object.keys(options).length;
  pushLog(state, `${tileName(tile)} 出去了，等 ${waiting} 家决定要不要吃碰`);
}

export function discard(state: MahjongState, memberId: string, tile: string, now: number) {
  if (state.phase !== "playing") throw new MahjongError("hand_inactive");
  if (state.claim) throw new MahjongError("claim_pending");
  const { index, seat } = requireSeat(state, memberId);
  if (state.turn !== index) throw new MahjongError("not_your_turn");
  if (typeof tile !== "string" || !tile) throw new MahjongError("invalid_tile");
  removeOne(seat.hand, tile);
  seat.hand = sortTiles(seat.hand);
  seat.discards.push(tile);
  seat.lastAction = `打出 ${tileName(tile)}`;
  state.lastDiscard = { seat: index, tile };
  state.drawn = null;
  state.justDrew = false;
  state.updatedAt = now;
  pushLog(state, `${seat.nickname} 打出 ${tileName(tile)}`);
  openClaims(state, index, tile, now);
}

function nextSeat(state: MahjongState, from: number): number {
  for (let offset = 1; offset <= MAHJONG_SEATS; offset += 1) {
    const index = (from + offset) % MAHJONG_SEATS;
    if (state.seats[index]) return index;
  }
  return -1;
}

function finishDraw(state: MahjongState, now: number) {
  state.phase = "result";
  state.turn = -1;
  state.claim = null;
  state.drawn = null;
  state.justDrew = false;
  state.deadline = now + RESULT_MS;
  state.result = {
    draw: true,
    winnerSeat: null,
    winnerName: null,
    fromSeat: null,
    fromName: null,
    tile: null,
    selfDraw: false,
    fans: [],
    points: 0,
    text: "牌墙摸完了，这一局荒庄，不输不赢。",
    hand: [],
    melds: [],
  };
  state.updatedAt = now;
  pushLog(state, "牌墙摸完，荒庄");
}

function settleWin(
  state: MahjongState,
  winner: number,
  from: number | null,
  tile: string,
  now: number,
) {
  const seat = state.seats[winner];
  if (!seat) return;
  const win = evaluateWin(seat.hand, seat.melds);
  if (!win) throw new MahjongError("cannot_hu");
  const selfDraw = from === null;
  if (selfDraw) {
    for (let index = 0; index < MAHJONG_SEATS; index += 1) {
      if (index === winner) continue;
      const other = state.seats[index];
      if (!other) continue;
      other.score -= win.points;
      other.lastAction = `付 ${win.points}`;
    }
    seat.score += win.points * (MAHJONG_SEATS - 1);
  } else {
    const payer = state.seats[from];
    if (payer) {
      payer.score -= win.points * 3;
      payer.lastAction = `点炮 -${win.points * 3}`;
    }
    seat.score += win.points * 3;
  }
  const fromSeat = from === null ? null : state.seats[from];
  state.phase = "result";
  state.turn = -1;
  state.claim = null;
  state.drawn = null;
  state.justDrew = false;
  state.deadline = now + RESULT_MS;
  state.result = {
    draw: false,
    winnerSeat: winner,
    winnerName: seat.nickname,
    fromSeat: from,
    fromName: fromSeat?.nickname ?? null,
    tile,
    selfDraw,
    fans: win.fans,
    points: win.points,
    text: selfDraw
      ? `${seat.nickname} 自摸 ${tileName(tile)}${win.fans.length ? ` · ${win.fans.join(" · ")}` : ""}`
      : `${seat.nickname} 胡了 ${fromSeat?.nickname ?? ""} 打出的 ${tileName(tile)}${win.fans.length ? ` · ${win.fans.join(" · ")}` : ""}`,
    hand: sortTiles(seat.hand),
    melds: seat.melds.map((meld) => ({ ...meld, tiles: [...meld.tiles] })),
  };
  seat.lastAction = "胡牌";
  // 胡牌者坐庄；庄家自摸则连庄
  state.dealer = winner;
  state.updatedAt = now;
  pushLog(
    state,
    `${seat.nickname} ${selfDraw ? "自摸" : "胡牌"}，${win.points} 分${win.fans.length ? `（${win.fans.join("、")}）` : ""}`,
  );
}

export function respondClaim(
  state: MahjongState,
  memberId: string,
  action: string,
  tiles: string[] | undefined,
  now: number,
) {
  if (!state.claim) throw new MahjongError("claim_closed");
  const claim = state.claim;
  const option = claim.options[memberId];
  if (!option) throw new MahjongError("cannot_claim");
  if (claim.responses[memberId] != null) throw new MahjongError("already_responded");
  let response: string;
  if (action === "pass") {
    response = "pass";
  } else if (action === "hu") {
    if (!option.hu) throw new MahjongError("cannot_hu");
    response = "hu";
  } else if (action === "gang") {
    if (!option.gang) throw new MahjongError("nothing_to_gang");
    response = "gang";
  } else if (action === "peng") {
    if (!option.peng) throw new MahjongError("cannot_claim");
    response = "peng";
  } else if (action === "chi") {
    const wanted = sortTiles(Array.isArray(tiles) ? tiles.filter((tile) => typeof tile === "string") : []);
    if (wanted.length !== 2) throw new MahjongError("invalid_chi");
    const matched = option.chi.find(
      (candidate) => sortTiles(candidate)[0] === wanted[0] && sortTiles(candidate)[1] === wanted[1],
    );
    if (!matched) throw new MahjongError("invalid_chi");
    response = `chi:${sortTiles(matched).join(",")}`;
  } else {
    throw new MahjongError("invalid_action");
  }
  claim.responses[memberId] = response;
  state.updatedAt = now;
  maybeResolveClaim(state, now);
}

function maybeResolveClaim(state: MahjongState, now: number) {
  const claim = state.claim;
  if (!claim) return;
  const answered = Object.values(claim.responses).every((value) => value != null);
  if (!answered) return;
  resolveClaim(state, now);
}

function nearest(state: MahjongState, from: number, seats: number[]): number {
  let best = -1;
  let bestDistance = MAHJONG_SEATS + 1;
  for (const index of seats) {
    const distance = (index - from + MAHJONG_SEATS) % MAHJONG_SEATS;
    if (distance < bestDistance) {
      bestDistance = distance;
      best = index;
    }
  }
  return best;
}

function resolveClaim(state: MahjongState, now: number) {
  const claim = state.claim;
  if (!claim) return;
  const entries = Object.entries(claim.responses);
  const seatOf = (memberId: string) => seatIndex(state, memberId);
  const winners = entries
    .filter(([, response]) => response === "hu")
    .map(([memberId]) => seatOf(memberId))
    .filter((index) => index >= 0);
  if (winners.length) {
    const winner = nearest(state, claim.from, winners);
    const seat = state.seats[winner]!;
    const tile = claim.tile;
    seat.hand.push(tile);
    seat.hand = sortTiles(seat.hand);
    takeDiscard(state, claim.from, tile);
    pushLog(state, `${seat.nickname} 喊胡`);
    settleWin(state, winner, claim.from, tile, now);
    return;
  }
  const melders = entries
    .filter(([, response]) => response === "gang" || response === "peng")
    .map(([memberId]) => seatOf(memberId))
    .filter((index) => index >= 0);
  if (melders.length) {
    const index = nearest(state, claim.from, melders);
    const memberId = state.seats[index]!.memberId;
    const response = claim.responses[memberId];
    const seat = state.seats[index]!;
    const tile = claim.tile;
    if (response === "gang") {
      for (let copy = 0; copy < 3; copy += 1) removeOne(seat.hand, tile);
      seat.melds.push({ kind: "gang", tiles: [tile, tile, tile, tile], from: claim.from });
      seat.lastAction = `杠 ${tileName(tile)}`;
      takeDiscard(state, claim.from, tile);
      pushLog(state, `${seat.nickname} 明杠 ${tileName(tile)}`);
      state.claim = null;
      state.lastDiscard = null;
      state.turn = index;
      drawTile(state, index, now);
      return;
    }
    for (let copy = 0; copy < 2; copy += 1) removeOne(seat.hand, tile);
    seat.melds.push({ kind: "peng", tiles: [tile, tile, tile], from: claim.from });
    seat.lastAction = `碰 ${tileName(tile)}`;
    takeDiscard(state, claim.from, tile);
    pushLog(state, `${seat.nickname} 碰 ${tileName(tile)}`);
    state.claim = null;
    state.lastDiscard = null;
    state.turn = index;
    state.drawn = null;
    state.justDrew = false;
    state.deadline = now + TURN_MS;
    state.updatedAt = now;
    return;
  }
  const chiers = entries
    .filter(([, response]) => typeof response === "string" && response.startsWith("chi:"))
    .map(([memberId]) => seatOf(memberId))
    .filter((index) => index >= 0);
  if (chiers.length) {
    const index = nearest(state, claim.from, chiers);
    const memberId = state.seats[index]!.memberId;
    const response = claim.responses[memberId] ?? "";
    const tiles = response.slice(4).split(",").filter(Boolean);
    const seat = state.seats[index]!;
    const tile = claim.tile;
    for (const handTile of tiles) removeOne(seat.hand, handTile);
    seat.melds.push({ kind: "chi", tiles: sortTiles([tile, ...tiles]), from: claim.from });
    seat.lastAction = `吃 ${tileName(tile)}`;
    takeDiscard(state, claim.from, tile);
    pushLog(state, `${seat.nickname} 吃 ${tileName(tile)}`);
    state.claim = null;
    state.lastDiscard = null;
    state.turn = index;
    state.drawn = null;
    state.justDrew = false;
    state.deadline = now + TURN_MS;
    state.updatedAt = now;
    return;
  }
  state.claim = null;
  state.lastDiscard = null;
  const next = nextSeat(state, claim.from);
  if (next < 0) return;
  state.turn = -1;
  drawTile(state, next, now);
}

/* ---------------- 杠与自摸 ---------------- */

function drawReplacement(state: MahjongState, index: number, now: number) {
  const seat = state.seats[index];
  if (!seat) return;
  if (!state.wall.length) {
    finishDraw(state, now);
    return;
  }
  const tile = state.wall.pop()!;
  seat.hand.push(tile);
  seat.hand = sortTiles(seat.hand);
  state.drawn = tile;
  state.justDrew = true;
  state.turn = index;
  state.deadline = now + TURN_MS;
  state.updatedAt = now;
}

export function gang(state: MahjongState, memberId: string, tile: string, now: number) {
  if (state.phase !== "playing") throw new MahjongError("hand_inactive");
  if (state.claim) throw new MahjongError("claim_pending");
  const { index, seat } = requireSeat(state, memberId);
  if (state.turn !== index) throw new MahjongError("not_your_turn");
  const copies = seat.hand.filter((handTile) => handTile === tile).length;
  const upgrade = seat.melds.findIndex((meld) => meld.kind === "peng" && meld.tiles[0] === tile);
  if (upgrade >= 0 && copies >= 1) {
    removeOne(seat.hand, tile);
    seat.melds[upgrade] = {
      kind: "gang",
      tiles: [tile, tile, tile, tile],
      from: seat.melds[upgrade].from,
    };
    seat.lastAction = `补杠 ${tileName(tile)}`;
    pushLog(state, `${seat.nickname} 补杠 ${tileName(tile)}`);
    state.drawn = null;
    drawReplacement(state, index, now);
    return;
  }
  if (copies === 4) {
    for (let copy = 0; copy < 4; copy += 1) removeOne(seat.hand, tile);
    seat.melds.push({ kind: "angang", tiles: [tile, tile, tile, tile], from: null });
    seat.lastAction = `暗杠 ${tileName(tile)}`;
    pushLog(state, `${seat.nickname} 暗杠`);
    state.drawn = null;
    drawReplacement(state, index, now);
    return;
  }
  throw new MahjongError("nothing_to_gang");
}

export function huSelf(state: MahjongState, memberId: string, now: number) {
  if (state.phase !== "playing") throw new MahjongError("hand_inactive");
  if (state.claim) throw new MahjongError("claim_pending");
  const { index, seat } = requireSeat(state, memberId);
  if (state.turn !== index) throw new MahjongError("not_your_turn");
  if (!evaluateWin(seat.hand, seat.melds)) throw new MahjongError("cannot_hu");
  settleWin(state, index, null, state.drawn ?? seat.hand[seat.hand.length - 1] ?? "", now);
}

/* ---------------- 超时推进 ---------------- */

export function advance(state: MahjongState, now: number) {
  if (state.phase === "playing") {
    if (state.claim) {
      if (now < state.claim.deadline) return;
      resolveClaim(state, now);
      return;
    }
    if (state.turn < 0) return;
    if (now < state.deadline) return;
    const seat = state.seats[state.turn];
    if (!seat) {
      state.turn = -1;
      return;
    }
    const tile = state.drawn ?? seat.hand[seat.hand.length - 1];
    if (tile) {
      pushLog(state, `${seat.nickname} 超时，自动打出 ${tileName(tile)}`);
      seat.lastAction = "超时";
      discard(state, seat.memberId, tile, now);
    }
    return;
  }
  if (state.phase === "result" && state.deadline > 0 && now >= state.deadline) {
    if (seatedCount(state) === MAHJONG_SEATS) {
      startHand(state, now);
      return;
    }
    state.phase = "waiting";
    state.turn = -1;
    state.deadline = 0;
    state.result = null;
    state.wall = [];
    state.updatedAt = now;
  }
}

/* ---------------- 对外视图 ---------------- */

export type MahjongSeatView = {
  seat: number;
  id: string;
  nickname: string;
  score: number;
  handCount: number;
  melds: MahjongMeld[];
  discards: string[];
  lastAction: string;
  isDealer: boolean;
};

export type MahjongView = ReturnType<typeof publicTable>;

export function publicTable(state: MahjongState, viewerId: string) {
  const mine = seatIndex(state, viewerId);
  const mySeat = mine >= 0 ? state.seats[mine]! : null;
  const claim = state.claim;
  const myOption = claim?.options[viewerId] ?? null;
  const seats: (MahjongSeatView | null)[] = state.seats.map((seat, index) => {
    if (!seat) return null;
    return {
      seat: index,
      id: seat.memberId,
      nickname: seat.nickname,
      score: seat.score,
      handCount: seat.hand.length,
      melds: seat.melds.map((meld) => ({ ...meld, tiles: [...meld.tiles] })),
      discards: [...seat.discards],
      lastAction: seat.lastAction,
      isDealer: state.dealer === index,
    };
  });
  const gangs: string[] = [];
  const buGangs: string[] = [];
  if (mySeat) {
    const counts = countsOf(mySeat.hand);
    for (let index = 0; index < counts.length; index += 1) {
      if (counts[index] !== 4) continue;
      gangs.push(tileOfIndex(index));
    }
    for (const meld of mySeat.melds) {
      if (meld.kind !== "peng") continue;
      const tile = meld.tiles[0];
      if (mySeat.hand.includes(tile)) buGangs.push(tile);
    }
  }
  const canAct = state.phase === "playing" && !claim && state.turn === mine;
  const waitingFor = claim
    ? Object.entries(claim.responses)
        .filter(([, response]) => response == null)
        .map(([memberId]) => state.seats[seatIndex(state, memberId)]?.nickname ?? "")
        .filter(Boolean)
    : [];
  return {
    mode: state.mode,
    modeName: modeSpec(state.mode).name,
    phase: state.phase,
    handNo: state.handNo,
    dealer: state.dealer,
    turn: state.turn,
    wallCount: state.wall.length,
    deadline: claim ? claim.deadline : state.deadline,
    lastDiscard: state.lastDiscard,
    claim: claim
      ? {
          tile: claim.tile,
          from: claim.from,
          fromName: state.seats[claim.from]?.nickname ?? "",
          deadline: claim.deadline,
          waitingFor,
          youCanClaim: Boolean(myOption),
        }
      : null,
    seats,
    logs: state.logs,
    result: state.result,
    updatedAt: state.updatedAt,
    serverNow: Date.now(),
    viewer: {
      seat: mine < 0 ? null : mine,
      hand: mySeat ? sortTiles(mySeat.hand) : [],
      drawn: canAct && state.justDrew ? state.drawn : null,
      isTurn: canAct,
      canHu: Boolean(canAct && mySeat && state.justDrew && evaluateWin(mySeat.hand, mySeat.melds)),
      gangs,
      buGangs,
      claim: myOption
        ? {
            hu: myOption.hu,
            gang: myOption.gang,
            peng: myOption.peng,
            chi: myOption.chi.map((tiles) => sortTiles(tiles)),
          }
        : null,
      responded: claim?.responses[viewerId] ?? null,
    },
  };
}
