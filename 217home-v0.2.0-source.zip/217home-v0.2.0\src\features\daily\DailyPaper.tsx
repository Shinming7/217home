import { useEffect, useMemo, useState } from "react";
import {
  CITIES,
  EDITION,
  EVENTS,
  TICKET_RADAR,
  isFree,
  isUpcoming,
  parseDay,
  rangeLabel,
  shortDay,
  sortForToday,
  startOfToday,
  statusOf,
  weekday,
  type CityId,
  type DailyEvent,
} from "./events";

type CityFilter = CityId | "all";

const pad = (value: number) => String(value).padStart(2, "0");

function cityName(city: CityId): string {
  return CITIES.find((entry) => entry.id === city)?.name ?? "";
}

function sealOf(city: CityId): string {
  return CITIES.find((entry) => entry.id === city)?.seal ?? "?";
}

function EventCard({ event, today }: { event: DailyEvent; today: number }) {
  const status = statusOf(event, today);
  return (
    <details className="daily-event">
      <summary>
        <span className="daily-event-date">
          <b>{shortDay(event.start)}</b>
          <em>{weekday(event.start)}</em>
        </span>
        <span className="daily-event-main">
          <span className="daily-event-kind">{event.kind}</span>
          <span className="daily-event-title">{event.title}</span>
          <span className="daily-event-venue">{event.venue}</span>
        </span>
        <span className={`daily-status s-${status.key}`}>{status.label}</span>
        <span className="daily-event-mark" aria-hidden="true" />
      </summary>
      <div className="daily-event-body">
        <p className="daily-event-blurb">{event.blurb}</p>
        <p className="daily-event-facts">
          <span className="daily-fact-range">{rangeLabel(event)}</span>
          <span className="daily-fact-price">{event.price}</span>
          {event.tags.map((tag) => (
            <span className="daily-tag" key={tag}>
              {tag}
            </span>
          ))}
        </p>
        <a className="daily-source" href={event.sourceUrl} target="_blank" rel="noreferrer">
          {event.sourceLabel} ↗
        </a>
      </div>
    </details>
  );
}

export function DailyPaper({ onClose }: { onClose: () => void }) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const [city, setCity] = useState<CityFilter>("all");
  const [freeOnly, setFreeOnly] = useState(false);
  const today = useMemo(() => startOfToday(new Date()), []);

  const live = useMemo(
    () => sortForToday(EVENTS.filter((event) => isUpcoming(event, today)), today),
    [today],
  );

  const visible = useMemo(
    () => live.filter((event) => (freeOnly ? isFree(event) : true)),
    [live, freeOnly],
  );

  const lead = visible.find((event) => event.featured) ?? visible[0] ?? null;

  const week = useMemo(
    () =>
      Array.from({ length: 7 }, (_, index) => {
        const date = new Date(today);
        date.setDate(date.getDate() + index);
        const iso = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
        const opens = EVENTS.filter((event) => parseDay(event.start).getTime() === date.getTime());
        return { iso, today: index === 0, label: shortDay(iso), dow: weekday(iso), opens };
      }),
    [today],
  );

  const columns = useMemo(
    () =>
      CITIES.map((info) => ({
        ...info,
        events: visible.filter((event) => event.city === info.id),
      })).filter((column) => city === "all" || column.id === city),
    [visible, city],
  );

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: visible.length };
    for (const info of CITIES) {
      map[info.id] = visible.filter((event) => event.city === info.id).length;
    }
    return map;
  }, [visible]);

  const published = new Date(`${EDITION.publishedAt}T00:00:00`);
  const dateline = `${published.getFullYear()} 年 ${published.getMonth() + 1} 月 ${published.getDate()} 日 · ${weekday(
    EDITION.publishedAt,
  )}`;

  return (
    <div
      className="daily-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <article className="daily-sheet" role="dialog" aria-modal="true" aria-label="耍起日报">
        <button type="button" className="daily-close" onClick={onClose} aria-label="关闭">
          ×
        </button>
        <div className="daily">
        <div className="daily-topline">
          <span className="daily-issue">第 {EDITION.issue} 期</span>
          <span className="daily-dateline">{dateline}</span>
          <span className="daily-seals" aria-label="覆盖城市：深圳、广州、香港">
            {CITIES.map((info) => (
              <i key={info.id} title={info.name}>
                {info.seal}
              </i>
            ))}
          </span>
        </div>

        {lead ? (
          <section className="daily-lead" aria-label="本期头条">
            <div className="daily-lead-main">
              <div className="daily-lead-head">
                <span className="daily-lead-flag">本期头条</span>
                <span className="daily-lead-city">
                  {cityName(lead.city)} · {rangeLabel(lead)}
                </span>
              </div>
              <h3 className="daily-lead-title">{lead.title}</h3>
              <p className="daily-lead-meta">
                {lead.venue} · {lead.price}
              </p>
              <p className="daily-lead-text">{lead.blurb}</p>
            </div>
            <aside className="daily-lead-side" aria-label="未来七天">
              <p className="daily-week-title">未来七天</p>
              <ol className="daily-week">
                {week.map((day) => (
                  <li
                    key={day.iso}
                    className={[day.today ? "today" : "", day.opens.length ? "has" : ""].filter(Boolean).join(" ")}
                  >
                    <span>{day.today ? "今天" : day.dow}</span>
                    <b>{day.label}</b>
                    <em>{day.opens.length ? `${day.opens.length} 场` : "—"}</em>
                  </li>
                ))}
              </ol>
            </aside>
            <div className="daily-lead-foot">
              <span className={`daily-status s-${statusOf(lead, today).key}`}>
                {statusOf(lead, today).label}
              </span>
              {lead.tags.map((tag) => (
                <span className="daily-tag" key={tag}>
                  {tag}
                </span>
              ))}
              <a className="daily-source" href={lead.sourceUrl} target="_blank" rel="noreferrer">
                {lead.sourceLabel} ↗
              </a>
            </div>
          </section>
        ) : null}

        <div className="daily-toolbar">
          <div className="daily-cities" role="tablist" aria-label="按城市筛选">
            <button
              type="button"
              role="tab"
              aria-selected={city === "all"}
              className={city === "all" ? "daily-city active" : "daily-city"}
              onClick={() => setCity("all")}
            >
              全部
              <em>{counts.all}</em>
            </button>
            {CITIES.map((info) => (
              <button
                key={info.id}
                type="button"
                role="tab"
                aria-selected={city === info.id}
                className={city === info.id ? "daily-city active" : "daily-city"}
                onClick={() => setCity(info.id)}
              >
                {info.name}
                <em>{counts[info.id]}</em>
              </button>
            ))}
          </div>
          <button
            type="button"
            className={freeOnly ? "daily-free active" : "daily-free"}
            aria-pressed={freeOnly}
            onClick={() => setFreeOnly((current) => !current)}
          >
            只看免费
          </button>
        </div>

        {columns.every((column) => column.events.length === 0) ? (
          <p className="daily-empty">
            这一期没有符合条件的活动了。等编辑部下次出门回来，再贴新的。
          </p>
        ) : (
          <div className={city === "all" ? "daily-grid" : "daily-grid single"}>
            {columns.map((column) =>
              column.events.length === 0 && city === "all" ? null : (
                <section className="daily-col" key={column.id}>
                  <header className="daily-col-head">
                    <i className="daily-col-seal">{column.seal}</i>
                    <div>
                      <h4>{column.name}</h4>
                      <p>{column.note}</p>
                    </div>
                    <span className="daily-col-count">{column.events.length} 条</span>
                  </header>
                  {column.events.length ? (
                    column.events.map((event) => <EventCard event={event} today={today} key={event.id} />)
                  ) : (
                    <p className="daily-col-empty">这一类暂时没有，换一个筛选试试。</p>
                  )}
                </section>
              ),
            )}
          </div>
        )}

        <aside className="daily-radar" aria-label="票务雷达">
          <h4>票务雷达</h4>
          <ul>
            {TICKET_RADAR.map((item) => (
              <li key={item.id}>
                <span className="daily-radar-city">{sealOf(item.city)}</span>
                <div>
                  <strong>{item.title}</strong>
                  <p>{item.note}</p>
                </div>
                <span className={item.status === "已截止" ? "daily-radar-state off" : "daily-radar-state"}>
                  {item.status}
                </span>

                <a href={item.sourceUrl} target="_blank" rel="noreferrer" aria-label={`${item.title} 来源`}>
                  ↗
                </a>
              </li>
            ))}
          </ul>
        </aside>

        <footer className="daily-foot">
          <p>{EDITION.note}</p>
          <p className="daily-sign">
            {EDITION.editor} · 编辑于 {EDITION.publishedAt} · 三城活动人工整理
          </p>
        </footer>
        </div>
      </article>
    </div>
  );
}
