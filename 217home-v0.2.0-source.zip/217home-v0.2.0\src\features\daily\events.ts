// 耍起日报 · 三城活动数据
//
// 这是一份人工整理的「近期娱乐活动」清单：深圳、广州、香港各选几条值得出门的
// 展览 / 演出 / 音乐 / 节庆 / 运动，日期以主办方公开信息为准。
// 更新方式：直接改下面的 EVENTS，把 start / end 换成新日期，重新构建即可。
// 数据只在前端打包，不经过后端，也不会写入房间数据库。

export type CityId = "shenzhen" | "guangzhou" | "hongkong";

export type CityInfo = {
  id: CityId;
  name: string;
  seal: string;
  note: string;
};

export const CITIES: CityInfo[] = [
  { id: "shenzhen", name: "深圳", seal: "深", note: "书展、新馆与海边的展" },
  { id: "guangzhou", name: "广州", seal: "穗", note: "电音、设计周与爬塔" },
  { id: "hongkong", name: "香港", seal: "港", note: "像素嘉年华与维港爵士" },
];

export type EventKind = "展览" | "演出" | "音乐" | "节庆" | "运动" | "阅读" | "设计";

export type DailyEvent = {
  id: string;
  city: CityId;
  kind: EventKind;
  title: string;
  /** YYYY-MM-DD */
  start: string;
  /** YYYY-MM-DD；没有固定结束日期时留空 */
  end?: string;
  venue: string;
  price: string;
  blurb: string;
  tags: string[];
  sourceLabel: string;
  sourceUrl: string;
  featured?: boolean;
};

export const EDITION = {
  issue: "001",
  publishedAt: "2026-10-28",
  editor: "217 编辑部",
  note: "本期活动信息整理自主办方与官方媒体的公开报道，出发前请再看一眼官方最新公告（临时改期、售罄、天气取消都可能发生）。",
};

export const EVENTS: DailyEvent[] = [
  // ---------- 深圳 ----------
  {
    id: "sz-book-month",
    city: "shenzhen",
    kind: "阅读",
    title: "第二十七届深圳读书月",
    start: "2026-11-01",
    end: "2026-11-30",
    venue: "全市 · 湾区之眼 / 深圳书城",
    price: "免费",
    blurb:
      "288 项、约 2700 场活动铺满整个十一月。11 月 26–30 日的第八届深圳书展落在宝安「湾区之眼」，分会场还有「何以甲骨」甲骨文珍品展和 VR《妇好传说》。",
    tags: ["书展", "亲子", "免费"],
    sourceLabel: "深圳政府在线",
    sourceUrl: "https://www.sz.gov.cn/cn/xxgk/zfxxgj/gqdt/content/post_13044180.html",
  },
  {
    id: "sz-qianhai-museum",
    city: "shenzhen",
    kind: "展览",
    title: "深圳前海博物馆开馆",
    start: "2026-10-30",
    venue: "前海博物馆（宝安 · 前海）",
    price: "免费预约",
    blurb:
      "8 个开馆展览、3000 余件文物，加上 270 度山海景观的公共空间。新馆首周预约大概率紧张，出发前先盯官方放票。",
    tags: ["新馆", "文物", "要预约"],
    sourceLabel: "橙新闻",
    sourceUrl:
      "https://www.orangenews.hk/play/VZE7SxW/深圳前海博物館10月30日開館-8大展覽-270度山海景觀-附門票及預約攻略.shtml",
  },
  {
    id: "sz-folk-art",
    city: "shenzhen",
    kind: "展览",
    title: "山花奖作品展 & 广东民间工艺精品展",
    start: "2026-11-03",
    end: "2026-11-22",
    venue: "海上世界文化艺术中心 L2 / L3",
    price: "见场馆公告",
    blurb:
      "150 余件山花奖获奖作品，加 70 件（组）岭南工艺精品：陶瓷、刺绣、木雕、广彩、潮绣一次看齐，免费场次多，适合慢慢逛。",
    tags: ["民艺", "免费场次多"],
    sourceLabel: "南方+",
    sourceUrl: "https://www.nfnews.com/content/96qKpZN5yM.html",
  },
  {
    id: "sz-theatre-season",
    city: "shenzhen",
    kind: "演出",
    title: "第四届深圳湾区青年戏剧季",
    start: "2026-11-21",
    end: "2026-11-29",
    venue: "光明区 · 深圳国际美术馆、光明文化艺术中心等四馆",
    price: "剧目售票 · 活动多免费",
    blurb:
      "9 天、6 部戏、12 场演出：《绝对永生》《大地之门》首演，俄罗斯话剧《换心记》来交流。剧场外的沉浸式戏剧嘉年华、主创对谈、戏剧疗愈多在商圈免费开放。",
    tags: ["戏剧", "首演", "免费活动"],
    sourceLabel: "人民网",
    sourceUrl: "http://sz.people.com.cn/BIG5/n2/2026/1028/c202846-41734941.html",
  },

  // ---------- 广州 ----------
  {
    id: "gz-edc",
    city: "guangzhou",
    kind: "音乐",
    title: "EDC 广州 · 电音嘉年华",
    start: "2026-11-21",
    venue: "白云区 · 广州新门户（白云音乐公园）",
    price: "待官方开票",
    blurb:
      "全球顶级电音嘉年华 EDC 首次进入广州，13 组顶尖及先锋艺人集结，11 月 21 日在白云音乐公园开演。阵容与票档以官方为准。",
    tags: ["电音", "首进广州"],
    sourceLabel: "羊城晚报",
    sourceUrl: "https://news.ycwb.com/ikimvjktii/content_54327401.htm",
  },
  {
    id: "gz-tower-climb",
    city: "guangzhou",
    kind: "运动",
    title: "广州塔国际登高赛",
    start: "2026-11-29",
    venue: "广州塔",
    price: "报名制",
    blurb:
      "定档 11 月 29 日。今年新增湾区联赛首发和机器人登高赛，自己爬不动也可以去看机器人爬。",
    tags: ["爬塔", "亲子可看"],
    sourceLabel: "南方+",
    sourceUrl: "https://www.nfnews.com/content/O3GAZ9LVo0.html",
  },
  {
    id: "gz-design-week",
    city: "guangzhou",
    kind: "设计",
    title: "2026 广州设计周",
    start: "2026-12-03",
    end: "2026-12-07",
    venue: "保利世贸博览馆 · 国际采购中心 · 海珠国际会展中心",
    price: "预登记",
    blurb:
      "年度主题「幸福」，18 个展馆、20 多个国家 1000 余家品牌，三馆联动。专业观众提前预登记可以免排队。",
    tags: ["设计", "三馆联动"],
    sourceLabel: "广州设计周",
    sourceUrl: "https://www.cftge.cn/news481.html",
  },
  {
    id: "gz-marathon",
    city: "guangzhou",
    kind: "运动",
    title: "2026 广州马拉松",
    start: "2026-12-20",
    venue: "天河体育中心 → 海心沙星光大道",
    price: "报名 180 元（已截止）",
    blurb:
      "3 万人规模，12 月 20 日四枪起跑，路线还是「一江两岸」。报名 9 月已抽签结束，想上场只能等明年或找直通名额，去江边加油倒是随时可以。",
    tags: ["马拉松", "围观友好"],
    sourceLabel: "广州市体育局",
    sourceUrl: "http://tyj.gz.gov.cn/gkmlpt/content/10/10989/post_10989217.html",
  },

  // ---------- 香港 ----------
  {
    id: "hk-museum-carnival",
    city: "hongkong",
    kind: "节庆",
    title: "香港博物馆节 2026 · 缤纷博物馆嘉年华",
    start: "2026-10-31",
    end: "2026-11-01",
    venue: "香港文化中心露天广场（尖沙咀）",
    price: "免费",
    blurb:
      "今年主题「拼贴今昔」，把格仔茶档、香江药号、掟银币摊位做成像素装置，还有一米多高的巨型像素蛋挞、免费工作坊和露天电影——和 217 的像素小屋算是同好。",
    tags: ["像素", "免费", "亲子"],
    sourceLabel: "康文署博物馆",
    sourceUrl: "https://www.museums.gov.hk/tc/web/portal/mf2026-fun-at-museum-carnival.html",
    featured: true,
  },
  {
    id: "hk-jazz-fest",
    city: "hongkong",
    kind: "音乐",
    title: "国泰西九爵士音乐节",
    start: "2026-11-13",
    end: "2026-11-24",
    venue: "西九文化区 · 自由空间 / 艺术公园",
    price: "部分免费",
    blurb:
      "历来最大规模的一届：十天演出加草地疗愈空间，许志安首次加盟唱经典。白天逛展、傍晚在维港边听一场，是十一月最舒服的动线。",
    tags: ["爵士", "维港", "草地"],
    sourceLabel: "西九文化区",
    sourceUrl: "https://www.westk.hk/sc/event/cathay-westk-jazz-fest",
  },
];

export type RadarItem = {
  id: string;
  city: CityId;
  title: string;
  note: string;
  status: string;
  sourceLabel: string;
  sourceUrl: string;
};

/** 「票务雷达」：还没开演但该动手的事 */
export const TICKET_RADAR: RadarItem[] = [
  {
    id: "radar-eason",
    city: "hongkong",
    title: "陈奕迅 26 场录音骚",
    note: "开放登记，抽签购票，不是先到先得；想去的先把登记做掉。",
    status: "登记中",
    sourceLabel: "橙新闻",
    sourceUrl:
      "https://www.orangenews.hk/entnews/VZJBpqp/陳奕迅26場錄音騷開放登記-抽籤購票非鬥快-附連結.shtml",
  },
  {
    id: "radar-marathon",
    city: "guangzhou",
    title: "广州马拉松 12/20 开跑",
    note: "9 月已截止报名并完成抽签，今年只能当观众。",
    status: "已截止",
    sourceLabel: "广州市体育局",
    sourceUrl: "http://tyj.gz.gov.cn/gkmlpt/content/10/10989/post_10989217.html",
  },
];

const DAY_MS = 86_400_000;

export function parseDay(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1);
}

export function startOfToday(now: Date): number {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
}

export function dayDiff(fromISO: string, toStamp: number): number {
  return Math.round((toStamp - parseDay(fromISO).getTime()) / DAY_MS);
}

/** 10.31 / 11.01 这样的短日期 */
export function shortDay(iso: string): string {
  const date = parseDay(iso);
  return `${String(date.getMonth() + 1).padStart(2, "0")}.${String(date.getDate()).padStart(2, "0")}`;
}

const WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"];

export function weekday(iso: string): string {
  return `周${WEEKDAYS[parseDay(iso).getDay()]}`;
}

export function rangeLabel(event: DailyEvent): string {
  if (!event.end) return `${shortDay(event.start)} 起`;
  if (event.end === event.start) return shortDay(event.start);
  return `${shortDay(event.start)} – ${shortDay(event.end)}`;
}

export type EventStatus = {
  key: "today" | "soon" | "live" | "last" | "open" | "over";
  label: string;
};

export function statusOf(event: DailyEvent, today: number): EventStatus {
  const start = parseDay(event.start).getTime();
  const end = event.end ? parseDay(event.end).getTime() : null;

  if (start > today) {
    const days = Math.round((start - today) / DAY_MS);
    return { key: "soon", label: days <= 1 ? "明天开幕" : `${days} 天后` };
  }
  if (end !== null && end < today) return { key: "over", label: "已结束" };
  if (start === today) return { key: "today", label: "今天开幕" };
  if (end !== null) {
    const left = Math.round((end - today) / DAY_MS);
    if (left === 0) return { key: "last", label: "最后一天" };
    return { key: "live", label: `还剩 ${left} 天` };
  }
  return { key: "open", label: "进行中" };
}

export function isUpcoming(event: DailyEvent, today: number): boolean {
  // 没有结束日期的（长期开放）始终算在本期里
  if (!event.end) return true;
  return parseDay(event.end).getTime() >= today;
}

export function isFree(event: DailyEvent): boolean {
  return event.price.includes("免费");
}

/** 今天适合看的顺序：进行中 > 即将开幕 > 日期更近 */
export function sortForToday(events: DailyEvent[], today: number): DailyEvent[] {
  return [...events].sort((left, right) => {
    const lStart = parseDay(left.start).getTime();
    const rStart = parseDay(right.start).getTime();
    const lLive = lStart <= today;
    const rLive = rStart <= today;
    if (lLive !== rLive) return lLive ? -1 : 1;
    return lStart - rStart;
  });
}
