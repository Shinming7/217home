import { useCallback, useEffect, useRef, useState } from "react";
import { api, errorText } from "../../net/api";
import type { MahjongMeld, MahjongSeatView, MahjongTable } from "../../net/types";
import { Panel } from "../../ui/Panel";

type MahjongModalProps = { onClose: () => void };

const SUIT_TEXT: Record<string, string> = { m: "万", s: "条", p: "筒" };
const HONOR_TEXT: Record<string, string> = {
  "1z": "东",
  "2z": "南",
  "3z": "西",
  "4z": "北",
  "5z": "中",
  "6z": "发",
  "7z": "白",
};
const MODES: { id: string; name: string; desc: string }[] = [
  { id: "classic", name: "经典", desc: "108 张，可吃可碰" },
  { id: "nochi", name: "不吃", desc: "108 张，只能碰杠" },
  { id: "honors", name: "带字牌", desc: "136 张，加东南西北中发白" },
];
const MELD_LABEL: Record<MahjongMeld["kind"], string> = {
  chi: "吃",
  peng: "碰",
  gang: "杠",
  angang: "暗杠",
};

type Spot = "bottom" | "right" | "top" | "left";
const SPOTS: Spot[] = ["bottom", "right", "top", "left"];

function tileLabel(tile: string): string {
  if (tile[1] === "z") return HONOR_TEXT[tile] ?? "字";
  return `${tile[0]}${SUIT_TEXT[tile[1]] ?? tile[1]}`;
}

function faceOf(tile: string): { num: string; label: string } {
  if (tile[1] === "z") return { num: "", label: HONOR_TEXT[tile] ?? "字" };
  return { num: tile[0], label: SUIT_TEXT[tile[1]] ?? tile[1] };
}

function Tile({
  tile,
  small = false,
  ghost = false,
  drawn = false,
  onClick,
}: {
  tile: string;
  small?: boolean;
  ghost?: boolean;
  drawn?: boolean;
  onClick?: () => void;
}) {
  const className = [
    "mj-tile",
    `suit-${tile[1]}`,
    small ? "small" : "",
    ghost ? "ghost" : "",
    drawn ? "drawn" : "",
  ]
    .filter(Boolean)
    .join(" ");
  const face = faceOf(tile);
  const body = face.num ? (
    <>
      <span className="mj-tile-num">{face.num}</span>
      <span className="mj-tile-suit">{face.label}</span>
    </>
  ) : (
    <span className="mj-tile-honor">{face.label}</span>
  );
  if (!onClick) {
    return (
      <span className={className} aria-label={tileLabel(tile)}>
        {body}
      </span>
    );
  }
  return (
    <button type="button" className={className} onClick={onClick} aria-label={`打出 ${tileLabel(tile)}`}>
      {body}
    </button>
  );
}

function MeldGroup({ meld }: { meld: MahjongMeld }) {
  return (
    <span className={`mj-meld meld-${meld.kind}`}>
      {meld.tiles.map((tile, index) => (
        <Tile key={`${tile}-${index}`} tile={tile} small ghost={meld.kind === "angang"} />
      ))}
      <em>{MELD_LABEL[meld.kind]}</em>
    </span>
  );
}

function SeatCard({ seat, spot, turn, mine }: { seat: MahjongSeatView | null; spot: Spot; turn: boolean; mine: boolean }) {
  return (
    <div className={["mj-seat", `spot-${spot}`, seat ? "" : "empty", turn ? "turn" : "", mine ? "mine" : ""].filter(Boolean).join(" ")}>
      {seat ? (
        <>
          <div className="mj-seat-head">
            <span className="mj-name">
              {seat.isDealer ? <em className="mj-dealer">庄</em> : null}
              {seat.nickname}
              {mine ? <i>你</i> : null}
            </span>
            <span className={seat.score < 0 ? "mj-score negative" : "mj-score"}>{seat.score}</span>
          </div>
          {seat.melds.length ? (
            <div className="mj-melds">
              {seat.melds.map((meld, index) => (
                <MeldGroup key={index} meld={meld} />
              ))}
            </div>
          ) : null}
          <div className="mj-seat-body">
            <span className="mj-hand-count" aria-label={`手牌 ${seat.handCount} 张`}>
              {Array.from({ length: Math.min(seat.handCount, 13) }, (_, index) => (
                <span key={index} className="mj-back" />
              ))}
            </span>
            <span className="mj-seat-note">{seat.lastAction}</span>
          </div>
          {seat.discards.length ? (
            <div className="mj-river" aria-label="牌河">
              {seat.discards.slice(-12).map((tile, index) => (
                <Tile key={`${tile}-${index}`} tile={tile} small />
              ))}
            </div>
          ) : null}
        </>
      ) : (
        <span className="mj-seat-empty">空位</span>
      )}
    </div>
  );
}

export function MahjongModal({ onClose }: MahjongModalProps) {
  const [table, setTable] = useState<MahjongTable | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [clock, setClock] = useState(() => Date.now());
  const fetchedAt = useRef(Date.now());
  const inFlight = useRef(false);
  const mounted = useRef(true);

  const apply = useCallback((next: MahjongTable) => {
    setTable(next);
    fetchedAt.current = Date.now();
    setError("");
  }, []);

  const load = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    try {
      const result = await api.mahjongState();
      if (mounted.current) apply(result.table);
    } catch (caught) {
      if (mounted.current) setError(errorText(caught));
    } finally {
      inFlight.current = false;
    }
  }, [apply]);

  useEffect(() => {
    mounted.current = true;
    void load();
    const poll = window.setInterval(() => void load(), 1200);
    const tick = window.setInterval(() => setClock(Date.now()), 500);
    return () => {
      mounted.current = false;
      window.clearInterval(poll);
      window.clearInterval(tick);
    };
  }, [load]);

  const run = async (call: () => Promise<{ table: MahjongTable }>) => {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await call();
      if (mounted.current) apply(result.table);
    } catch (caught) {
      if (mounted.current) {
        setError(errorText(caught));
        void load();
      }
    } finally {
      if (mounted.current) setBusy(false);
    }
  };

  const rotation = table?.viewer.seat ?? 0;
  const estimatedNow = table ? table.serverNow + (clock - fetchedAt.current) : 0;
  const remaining = table && table.deadline > 0 ? Math.max(0, Math.ceil((table.deadline - estimatedNow) / 1000)) : 0;
  const viewer = table?.viewer;
  const seated = Boolean(table && viewer && viewer.seat != null);
  const allSeated = Boolean(table && table.seats.every((seat) => seat !== null));
  const mySeat = table && viewer && viewer.seat != null ? table.seats[viewer.seat] : null;
  const turnSeat = table && table.turn >= 0 ? table.seats[table.turn] : null;
  const canDiscard = Boolean(table && table.phase === "playing" && viewer?.isTurn && !busy);
  const claim = viewer?.claim ?? null;
  const myTurn = Boolean(viewer?.isTurn);

  const hand = viewer ? [...viewer.hand] : [];
  const drawn = viewer?.drawn ?? null;
  if (drawn) {
    const at = hand.lastIndexOf(drawn);
    if (at >= 0) hand.splice(at, 1);
  }

  return (
    <Panel kicker="MAHJONG · 217" title="客厅麻将" wide onClose={onClose}>
      <div className="mj-top">
        <span className="poker-chip-stat">第 {table?.handNo ?? 0} 局</span>
        <span className="poker-chip-stat">{table?.modeName ?? "经典"}玩法</span>
        <span className="poker-chip-stat">牌墙 {table?.wallCount ?? 108} 张</span>
        <span className="poker-chip-stat">
          {table?.phase === "playing"
            ? table.claim
              ? "等吃碰"
              : turnSeat
                ? `${turnSeat.nickname} 出牌`
                : "进行中"
            : table?.phase === "result"
              ? "本局结束"
              : "等人入座"}
        </span>
        {table?.phase === "playing" && table.deadline > 0 && (table.claim || turnSeat) ? (
          <span className="poker-chip-stat clock">{remaining}s</span>
        ) : null}
      </div>

      {table && table.phase !== "playing" && viewer?.seat != null ? (
        <div className="mj-modes" role="group" aria-label="玩法">
          {MODES.map((mode) => (
            <button
              key={mode.id}
              type="button"
              className={table.mode === mode.id ? "mj-mode active" : "mj-mode"}
              title={mode.desc}
              disabled={busy}
              onClick={() => void run(() => api.mahjongSetMode(mode.id))}
            >
              {mode.name}
            </button>
          ))}
        </div>
      ) : null}

      <div className="mj-table">
        <div className="mj-center">
          <div className="mj-wall">
            <span>牌墙</span>
            <strong>{table?.wallCount ?? 0}</strong>
          </div>

          {table?.phase === "result" && table.result ? (
            <div className="mj-result">
              <p>{table.result.text}</p>
              <span>
                {table.result.points > 0 ? `${table.result.points} 分` : "荒庄"} · 下一局 {remaining}s
              </span>
              {table.result.hand.length ? (
                <div className="mj-result-hand">
                  {table.result.hand.map((tile, index) => (
                    <Tile key={`${tile}-${index}`} tile={tile} small />
                  ))}
                </div>
              ) : null}
            </div>
          ) : table?.claim ? (
            <div className="mj-claim-banner">
              <Tile tile={table.claim.tile} drawn />
              <p>
                {table.claim.fromName} 打出的牌 · 等 {table.claim.waitingFor.join("、") || "…"}
              </p>
            </div>
          ) : table?.phase === "playing" ? (
            <div className="mj-center-hint">
              <p>{turnSeat ? `${turnSeat.nickname} 正在想` : "开局中"}</p>
              <span>点自己的牌就能打出</span>
            </div>
          ) : (
            <div className="mj-center-hint">
              <p>{allSeated ? "人齐了，马上开局" : `还差 ${4 - (table?.seats.filter(Boolean).length ?? 0)} 位住户`}</p>
              <span>4 人一桌，坐下就自动开局</span>
            </div>
          )}

          {table && table.seats.some((seat) => seat?.discards.length) ? (
            <div className="mj-center-rivers">
              {table.seats.map((seat, index) =>
                seat?.discards.length ? (
                  <span key={index} className="mj-center-river">
                    {seat.discards.slice(-3).map((tile, tileIndex) => (
                      <Tile key={`${tile}-${tileIndex}`} tile={tile} small ghost />
                    ))}
                  </span>
                ) : null,
              )}
            </div>
          ) : null}
        </div>

        {SPOTS.map((spot, displayIndex) => {
          const seatIndex = (displayIndex + rotation) % 4;
          const seat = table?.seats[seatIndex] ?? null;
          return (
            <SeatCard
              key={spot}
              spot={spot}
              seat={seat}
              turn={Boolean(table && table.phase === "playing" && !table.claim && table.turn === seatIndex)}
              mine={seatIndex === rotation}
            />
          );
        })}
      </div>

      {error ? (
        <p className="form-error" role="alert">
          {error}
        </p>
      ) : null}

      {seated ? (
        <div className="mj-hand-wrap">
          <span className="mj-hand-label">
            {mySeat?.nickname ?? "我"} · {viewer?.hand.length ?? 0} 张
            {myTurn ? " · 轮到你了" : ""}
          </span>
          <div className="mj-hand">
            {hand.map((tile, index) => (
              <Tile
                key={`${tile}-${index}`}
                tile={tile}
                onClick={canDiscard ? () => void run(() => api.mahjongDiscard(tile)) : undefined}
              />
            ))}
            {drawn ? (
              <Tile
                tile={drawn}
                drawn
                onClick={canDiscard ? () => void run(() => api.mahjongDiscard(drawn)) : undefined}
              />
            ) : null}
          </div>
        </div>
      ) : null}

      {(table?.logs.length ?? 0) > 0 ? (
        <ul className="poker-logs">
          {table!.logs.slice(-4).map((line, index) => (
            <li key={index}>{line}</li>
          ))}
        </ul>
      ) : null}

      <div className="poker-actions">
        {!table ? (
          <p className="panel-note">正在把麻将桌摆好……</p>
        ) : !seated ? (
          <>
            <p className="poker-hint">
              4 位住户一桌，东家起手 14 张。可吃、碰、杠，自摸或点炮都能胡；每人 1000 分起，胡牌者坐庄。
            </p>
            <button
              className="pixel-btn primary"
              disabled={busy}
              onClick={() => void run(api.mahjongJoin)}
            >
              {busy ? "正在坐下…" : "坐下打麻将"}
            </button>
          </>
        ) : table.phase === "result" ? (
          <>
            <div className="poker-wait-row">
              <span className="poker-hint">
                {table.result?.text ?? "这一局结束了"}
                {table.result && !table.result.draw ? ` · 赢家 ${table.result.winnerName}` : ""}
              </span>
              <button
                className="pixel-btn primary"
                disabled={busy || !allSeated}
                onClick={() => void run(api.mahjongStart)}
              >
                直接开下一局
              </button>
              <button className="pixel-btn danger" disabled={busy} onClick={() => void run(api.mahjongLeave)}>
                离开麻将桌
              </button>
            </div>
          </>
        ) : claim ? (
          <>
            <div className="mj-claim-row">
              <span className="poker-your-turn">
                {viewer?.responded ? "已经决定，等其他家" : `${table.claim ? tileLabel(table.claim.tile) : ""} 可以要`}
              </span>
              {viewer?.responded ? null : (
                <>
                  {claim.hu ? (
                    <button className="pixel-btn primary" disabled={busy} onClick={() => void run(() => api.mahjongClaim("hu"))}>
                      胡
                    </button>
                  ) : null}
                  {claim.gang ? (
                    <button className="pixel-btn" disabled={busy} onClick={() => void run(() => api.mahjongClaim("gang"))}>
                      杠
                    </button>
                  ) : null}
                  {claim.peng ? (
                    <button className="pixel-btn" disabled={busy} onClick={() => void run(() => api.mahjongClaim("peng"))}>
                      碰
                    </button>
                  ) : null}
                  {claim.chi.map((tiles) => (
                    <button
                      key={tiles.join("-")}
                      className="pixel-btn"
                      disabled={busy}
                      onClick={() => void run(() => api.mahjongClaim("chi", tiles))}
                    >
                      吃 {tiles.map((tile) => tile[0]).join("")}
                    </button>
                  ))}
                  <button className="pixel-btn danger" disabled={busy} onClick={() => void run(() => api.mahjongClaim("pass"))}>
                    过
                  </button>
                </>
              )}
            </div>
          </>
        ) : myTurn ? (
          <>
            <div className="poker-wait-row">
              <span className="poker-your-turn">轮到你 · {remaining}s</span>
              <span className="poker-hint">点一张牌打出</span>
              {viewer?.canHu ? (
                <button className="pixel-btn primary" disabled={busy} onClick={() => void run(api.mahjongHu)}>
                  自摸
                </button>
              ) : null}
              {viewer?.gangs.map((tile) => (
                <button key={`gang-${tile}`} className="pixel-btn" disabled={busy} onClick={() => void run(() => api.mahjongGang(tile))}>
                  暗杠 {tileLabel(tile)}
                </button>
              ))}
              {viewer?.buGangs.map((tile) => (
                <button key={`bu-${tile}`} className="pixel-btn" disabled={busy} onClick={() => void run(() => api.mahjongGang(tile))}>
                  补杠 {tileLabel(tile)}
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <div className="poker-wait-row">
              <span className="poker-hint">
                {table.claim
                  ? `等 ${table.claim.waitingFor.join("、") || "其他家"} 决定要不要吃碰 · ${remaining}s`
                  : turnSeat
                    ? `等 ${turnSeat.nickname} 出牌 · ${remaining}s`
                    : "准备开局"}
              </span>
              <button className="pixel-btn danger" disabled={busy} onClick={() => void run(api.mahjongLeave)}>
                离开麻将桌
              </button>
            </div>
          </>
        )}
      </div>
    </Panel>
  );
}
