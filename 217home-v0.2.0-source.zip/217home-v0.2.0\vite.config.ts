import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const proxy = {
  "/functions/v1/app": "http://127.0.0.1:8000",
  "/__mock": "http://127.0.0.1:8000",
};

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": fileURLToPath(new URL(".", import.meta.url)) } },
  server: {
    host: "127.0.0.1",
    proxy,
    // 编辑器/工具常用「临时目录 + 重命名」方式落盘，watcher 盯到这种临时文件会因 EBUSY 崩掉
    watch: { ignored: ["**/*.tmpdir/**", "**/node_modules/**", "**/.git/**"] },
  },
  preview: { host: "127.0.0.1", proxy },
  build: { outDir: "dist" },
});
