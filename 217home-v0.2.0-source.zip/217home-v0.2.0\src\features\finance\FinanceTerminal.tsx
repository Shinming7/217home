import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, errorText } from "../../net/api";
import type { MarketPayload, MarketQuote } from "../../net/types";
import { Panel } from "../../ui/Panel";

const REFRESH_SECONDS = 10;
const HISTORY_POINTS = 40;

function formatPrice(value: number | null): string {
  if (value === null) return "—";
  const digits = Math.abs(value) >= 1000 ? 0 : 2;
  return value.toLocaleString("zh-CN", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

function formatSigned(value: number | null, digits = 2): string {
  if (value === null) return "—";
  const text = Math.abs(value).toLocaleString("zh-CN", { minimumFractionDigits: digits, maximumFractionDigits: digits });
  return `${value > 0 ? "+" : value < 0 ? "-" : ""}${text}`;
}

function formatPct(value: number | null): string {
  if (value === null) return "—";
  return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function formatAmount(value: number | null): string {
  if (value === null || value <= 0) return "—";
  if (value >= 1e8) return `${(value / 1e8).toFixed(2)} 亿`;
  if (value >= 1e4) return `${(value / 1e4).toFixed(0)} 万`;
  return value.toFixed(0);
}

function clockLabel(ms: number): string {
  const date = new Date(ms);
  if (Number.isNaN(date.getTime())) return "--:--:--";
  return [date.getHours(), date.getMinutes(), date.getSeconds()]
    .map((part) => part.toString().padStart(2, "0"))
    .join(":");
}

function trendClass(value: number | null): string {
  if (value === null || value === 0) return "fin-flat";
  return value > 0 ? "fin-up" : "fin-down";
}

function Spark({ values, up }: { values: number[]; up: boolean }) {
  if (values.length < 2) return <span className="fin-spark fin-spark-empty" aria-hidden="true" />;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const points = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * 64;
      const y = 19 - ((value - min) / span) * 17;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg className={up ? "fin-spark fin-up" : "fin-spark fin-down"} viewBox="0 0 64 20" preserveAspectRatio="none" aria-hidden="true">
      <polyline points={points} />
    </svg>
  );
}

function QuoteRow({ item, history }: { item: MarketQuote; history: number[] }) {
  const tone = trendClass(item.changePct);
  return (
    <li className="fin-row">
      <div className="fin-name">
        <strong>{item.name}</strong>
        <span>
          {item.code} · {item.unit}
        </span>
      </div>
      <div className="fin-price" title={`开 ${formatPrice(item.open)} · 高 ${formatPrice(item.high)} · 低 ${formatPrice(item.low)} · 昨收 ${formatPrice(item.prevClose)} · 额 ${formatAmount(item.amount)}`}>
        {formatPrice(item.price)}
      </div>
      <div className={`fin-change ${tone}`}>
        <strong>{formatPct(item.changePct)}</strong>
        <span>{formatSigned(item.change, Math.abs(item.price ?? 0) >= 1000 ? 0 : 2)}</span>
      </div>
      <Spark values={history} up={(item.changePct ?? 0) >= 0} />
    </li>
  );
}

export function FinanceTerminal({ onClose }: { onClose: () => void }) {
  const [data, setData] = useState<MarketPayload | null>(null);
  const [history, setHistory] = useState<Record<string, number[]>>({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [countdown, setCountdown] = useState(REFRESH_SECONDS);
  const countdownRef = useRef(REFRESH_SECONDS);

  const load = useCallback(async (manual = false) => {
    if (manual) setRefreshing(true);
    try {
      const payload = await api.market();
      setData(payload);
      setError("");
      setHistory((previous) => {
        const next: Record<string, number[]> = { ...previous };
        for (const group of payload.groups) {
          for (const item of group.items) {
            if (item.price === null) continue;
            const trail = next[item.secid] ? [...next[item.secid], item.price] : [item.price];
            next[item.secid] = trail.slice(-HISTORY_POINTS);
          }
        }
        return next;
      });
    } catch (caught) {
      setError(errorText(caught));
    } finally {
      setLoading(false);
      setRefreshing(false);
      countdownRef.current = REFRESH_SECONDS;
      setCountdown(REFRESH_SECONDS);
    }
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => {
      if (document.hidden) return;
      countdownRef.current -= 1;
      if (countdownRef.current <= 0) {
        countdownRef.current = REFRESH_SECONDS;
        void load();
      }
      setCountdown(countdownRef.current);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [load]);

  const ticker = useMemo(() => {
    if (!data) return [];
    return data.groups.flatMap((group) => group.items.map((item) => ({ ...item, group: group.label })));
  }, [data]);

  const session = data?.session;
  const latest = data?.asOf ?? null;

  return (
    <Panel kicker="217 FINANCE · 行情终端" title="217金融" wide onClose={onClose}>
      <div className="fin-screen">
        <div className="fin-statusbar">
          <span className={session?.aShareOpen ? "fin-badge live" : "fin-badge"}>
            <i aria-hidden="true" />
            {session?.label ?? "连接行情中"}
          </span>
          <span
            className={session?.usOpen ? "fin-badge live" : "fin-badge"}
            title={session?.usNote ?? "纽约时间"}
          >
            <i aria-hidden="true" />
            {session ? `美股 · ${session.usLabel}` : "美股 · …"}
          </span>
          {data?.stale ? <span className="fin-badge warn">缓存数据</span> : null}
          <span className="fin-stamp">
            {latest ? `数据时间 ${clockLabel(latest)}` : "正在开机…"}
            {session?.note ? ` · ${session.note}` : ""}
          </span>
          <button className="fin-refresh" onClick={() => void load(true)} disabled={refreshing}>
            {refreshing ? "刷新中…" : `刷新 · ${countdown}s`}
          </button>
        </div>

        <div className="fin-ticker" aria-hidden="true">
          <div className="fin-ticker-track">
            {[0, 1].map((copy) => (
              <div className="fin-ticker-run" key={copy}>
                {ticker.map((item) => (
                  <span className={`fin-ticker-item ${trendClass(item.changePct)}`} key={`${copy}-${item.secid}`}>
                    <b>{item.name}</b>
                    <em>{formatPrice(item.price)}</em>
                    <span>{formatPct(item.changePct)}</span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>

        {error ? (
          <p className="form-error" role="alert">
            {error}
          </p>
        ) : null}

        {loading && !data ? <p className="panel-note fin-loading">正在接收第一条行情……</p> : null}

        <div className="fin-groups">
          {data?.groups.map((group) => (
            <section className="fin-group" key={group.id}>
              <header className="fin-group-head">
                <h3>{group.label}</h3>
                <span>{group.blurb}</span>
              </header>
              {group.items.length ? (
                <ul className="fin-rows">
                  {group.items.map((item) => (
                    <QuoteRow key={item.secid} item={item} history={history[item.secid] ?? []} />
                  ))}
                </ul>
              ) : (
                <p className="fin-empty">这条线路暂时没有数据，等下一次刷新。</p>
              )}
            </section>
          ))}
        </div>

        <p className="fin-foot">
          数据来自新浪财经公开行情接口 · 每 {REFRESH_SECONDS} 秒自动刷新 · 盘后为最近一次收盘价 · 仅供参考，不构成投资建议
        </p>
      </div>
    </Panel>
  );
}
