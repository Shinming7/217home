/**
 * 217 金融 · 行情服务
 *
 * 数据来自新浪财经公开行情接口（hq.sinajs.cn，无需密钥，需要带 Referer）。
 * 一次请求取回全部标的，服务端缓存 6 秒；上游失败时退回本进程里的最后一份好数据并标记 stale。
 *
 * 新浪返回 GBK 文本，形如：var hq_str_sh000001="上证指数,3676.9185,...";
 * 各类标的字段含义不同，按 feed 类型分别解析，具体见 parseQuote。
 */

export type MarketQuote = {
  secid: string;
  code: string;
  name: string;
  unit: string;
  price: number | null;
  change: number | null;
  changePct: number | null;
  open: number | null;
  high: number | null;
  low: number | null;
  prevClose: number | null;
  amount: number | null;
};

export type MarketGroup = {
  id: string;
  label: string;
  blurb: string;
  items: MarketQuote[];
};

export type MarketSession = {
  aShareOpen: boolean;
  label: string;
  note: string;
  usOpen: boolean;
  usLabel: string;
  usNote: string;
};

export type MarketPayload = {
  asOf: number;
  fetchedAt: string;
  source: "sina";
  stale: boolean;
  session: MarketSession;
  groups: MarketGroup[];
};

type FeedKind = "cn" | "hk" | "us" | "hf" | "nf";
type CatalogItem = { feed: string; name: string; unit: string; kind: FeedKind };
type GroupSpec = { id: string; label: string; blurb: string; items: CatalogItem[] };

/** 字段含义：cn=沪深指数/个股，hk=港股指数，us=美股指数，hf=外盘期货，nf=国内商品期货 */
const GROUPS: GroupSpec[] = [
  {
    id: "index",
    label: "大盘指数",
    blurb: "沪深 · 港股 · 美股",
    items: [
      { feed: "gb_$inx", name: "标普500", unit: "点", kind: "us" },
      { feed: "gb_$ixic", name: "纳斯达克", unit: "点", kind: "us" },
      { feed: "gb_$dji", name: "道琼斯", unit: "点", kind: "us" },
      { feed: "rt_hkHSI", name: "恒生指数", unit: "点", kind: "hk" },
      { feed: "sh000001", name: "上证指数", unit: "点", kind: "cn" },
      { feed: "sz399001", name: "深证成指", unit: "点", kind: "cn" },
      { feed: "sz399006", name: "创业板指", unit: "点", kind: "cn" },
      { feed: "sh000300", name: "沪深300", unit: "点", kind: "cn" },
      { feed: "sh000688", name: "科创50", unit: "点", kind: "cn" },
    ],
  },
  {
    id: "stock",
    label: "美股",
    blurb: "美国科技 · 半导体 · 医药 · 金融龙头",
    items: [
      { feed: "gb_nvda", name: "英伟达", unit: "美元", kind: "us" },
      { feed: "gb_aapl", name: "苹果", unit: "美元", kind: "us" },
      { feed: "gb_msft", name: "微软", unit: "美元", kind: "us" },
      { feed: "gb_googl", name: "谷歌", unit: "美元", kind: "us" },
      { feed: "gb_amzn", name: "亚马逊", unit: "美元", kind: "us" },
      { feed: "gb_meta", name: "Meta", unit: "美元", kind: "us" },
      { feed: "gb_tsla", name: "特斯拉", unit: "美元", kind: "us" },
      { feed: "gb_avgo", name: "博通", unit: "美元", kind: "us" },
      { feed: "gb_lly", name: "礼来", unit: "美元", kind: "us" },
      { feed: "gb_jpm", name: "摩根大通", unit: "美元", kind: "us" },
    ],
  },
  {
    id: "commodity",
    label: "商品期货",
    blurb: "贵金属 · 能源 · 有色 · 黑色 · 农产品",
    items: [
      { feed: "hf_GC", name: "COMEX黄金", unit: "美元/盎司", kind: "hf" },
      { feed: "hf_SI", name: "COMEX白银", unit: "美元/盎司", kind: "hf" },
      { feed: "hf_CL", name: "NYMEX原油", unit: "美元/桶", kind: "hf" },
      { feed: "hf_HG", name: "COMEX铜", unit: "美分/磅", kind: "hf" },
      { feed: "nf_AU0", name: "沪金主连", unit: "元/克", kind: "nf" },
      { feed: "nf_AG0", name: "沪银主连", unit: "元/千克", kind: "nf" },
      { feed: "nf_CU0", name: "沪铜主连", unit: "元/吨", kind: "nf" },
      { feed: "nf_RB0", name: "螺纹钢主连", unit: "元/吨", kind: "nf" },
      { feed: "nf_I0", name: "铁矿石主连", unit: "元/吨", kind: "nf" },
      { feed: "nf_M0", name: "豆粕主连", unit: "元/吨", kind: "nf" },
    ],
  },
  {
    id: "freight",
    label: "航运运价",
    blurb: "上海国际能源交易中心 · 集运指数（欧线）",
    items: [{ feed: "nf_EC0", name: "欧线集运主连", unit: "点", kind: "nf" }],
  },
];

const FEED = "https://hq.sinajs.cn/list=";
const TTL_MS = 6_000;
const FETCH_TIMEOUT_MS = 6_000;

function num(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function pctOf(price: number | null, prev: number | null): number | null {
  if (price === null || prev === null || prev === 0) return null;
  return ((price - prev) / prev) * 100;
}

function symbolOf(feed: string): string {
  if (feed.startsWith("rt_hk")) return feed.slice(6);
  if (feed.startsWith("gb_$")) return feed.slice(4).toUpperCase();
  if (feed.startsWith("hf_") || feed.startsWith("nf_")) return feed.slice(3);
  if (feed.startsWith("sh") || feed.startsWith("sz")) return feed.slice(2);
  return feed;
}

/** 拆一行 var hq_str_x="a,b,c"，返回字段数组；没有数据返回空数组 */
function splitFields(raw: string): string[] {
  return raw ? raw.split(",") : [];
}

function parseQuote(item: CatalogItem, fields: string[]): Omit<MarketQuote, "name" | "unit" | "secid" | "code"> {
  const f = (index: number) => num(fields[index]);
  const empty = {
    price: null as number | null,
    change: null as number | null,
    changePct: null as number | null,
    open: null as number | null,
    high: null as number | null,
    low: null as number | null,
    prevClose: null as number | null,
    amount: null as number | null,
  };
  if (!fields.length) return empty;

  if (item.kind === "cn") {
    // 名称,今开,昨收,现价,最高,最低,买一,卖一,成交量(股),成交额(元),...
    const open = f(1);
    const prevClose = f(2);
    const quoted = f(3);
    const price = quoted !== null && quoted !== 0 ? quoted : prevClose;
    const high = f(4);
    const low = f(5);
    const amount = f(9);
    return { price, prevClose, open, high, low, amount, change: price !== null && prevClose !== null ? price - prevClose : null, changePct: pctOf(price, prevClose) };
  }

  if (item.kind === "hk") {
    // 代码,名称,今开,昨收,最高,最低,现价,涨跌,涨跌%,...
    const open = f(2);
    const prevClose = f(3);
    const quoted = f(6);
    const price = quoted !== null && quoted !== 0 ? quoted : prevClose;
    return { price, prevClose, open, high: f(4), low: f(5), amount: f(11), change: f(7), changePct: f(8) };
  }

  if (item.kind === "us") {
    // 名称,现价,涨跌%,时间,涨跌额,今开,最高,最低,52周高,52周低,...
    const quoted = f(1);
    const price = quoted !== null && quoted !== 0 ? quoted : null;
    const change = f(4);
    const prevClose = price !== null && change !== null ? price - change : null;
    return { price, prevClose, open: f(5), high: f(6), low: f(7), amount: null, change, changePct: f(2) };
  }

  if (item.kind === "hf") {
    // 现价,?,买价,卖价,最高,最低,时间,昨收,昨结,...
    const quoted = f(0);
    const price = quoted !== null && quoted !== 0 ? quoted : null;
    const prevClose = f(7);
    return { price, prevClose, open: null, high: f(4), low: f(5), amount: null, change: price !== null && prevClose !== null ? price - prevClose : null, changePct: pctOf(price, prevClose) };
  }

  // nf：名称,时间,今开,最高,最低,?,买价,卖价,现价,?,昨结,买量,卖量,持仓,成交量,交易所,品种,日期,...
  const quoted = f(8);
  const price = quoted !== null && quoted !== 0 ? quoted : null;
  const prevClose = f(10);
  return { price, prevClose, open: f(2), high: f(3), low: f(4), amount: null, change: price !== null && prevClose !== null ? price - prevClose : null, changePct: pctOf(price, prevClose) };
}

function decodeFeed(bytes: Uint8Array): string {
  try {
    return new TextDecoder("gbk").decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}

function clockIn(timeZone: string, now: Date): { weekday: boolean; minutes: number } {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);
  const read = (type: string) => parts.find((part) => part.type === type)?.value ?? "";
  return {
    weekday: !["Sat", "Sun"].includes(read("weekday")),
    minutes: Number(read("hour")) * 60 + Number(read("minute")),
  };
}

function aShareSession(now: Date): { aShareOpen: boolean; label: string; note: string } {
  const { weekday, minutes } = clockIn("Asia/Shanghai", now);
  if (!weekday) {
    return { aShareOpen: false, label: "周末休市", note: "显示上一交易日收盘行情" };
  }
  if (minutes >= 570 && minutes < 690) {
    return { aShareOpen: true, label: "A股 盘中", note: "上午交易时段 09:30–11:30" };
  }
  if (minutes >= 690 && minutes < 780) {
    return { aShareOpen: false, label: "午间休市", note: "下午 13:00 继续交易" };
  }
  if (minutes >= 780 && minutes < 900) {
    return { aShareOpen: true, label: "A股 盘中", note: "下午交易时段 13:00–15:00" };
  }
  if (minutes < 570) {
    return { aShareOpen: false, label: "盘前", note: "09:30 开盘，商品夜盘仍在交易" };
  }
  return { aShareOpen: false, label: "A股 已收盘", note: "商品夜盘 21:00 开市" };
}

function usSession(now: Date): { usOpen: boolean; usLabel: string; usNote: string } {
  const { weekday, minutes } = clockIn("America/New_York", now);
  if (!weekday) {
    return { usOpen: false, usLabel: "休市", usNote: "周末休市，显示上一交易日收盘" };
  }
  if (minutes >= 570 && minutes < 960) {
    return { usOpen: true, usLabel: "盘中", usNote: "美东 09:30–16:00" };
  }
  if (minutes < 570) {
    return { usOpen: false, usLabel: "盘前", usNote: "美东 09:30 开盘" };
  }
  return { usOpen: false, usLabel: "已收盘", usNote: "美东 16:00 收盘" };
}

function sessionInfo(now = new Date()): MarketSession {
  return { ...aShareSession(now), ...usSession(now) };
}

async function fetchMarket(): Promise<MarketPayload> {
  const all = GROUPS.flatMap((group) => group.items);
  const response = await fetch(`${FEED}${all.map((item) => item.feed).join(",")}`, {
    headers: {
      referer: "https://finance.sina.com.cn",
      "user-agent": "Mozilla/5.0 (compatible; 217house/1.0; +https://github.com/Shinming7/217home)",
    },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (!response.ok) throw new Error(`quote_http_${response.status}`);

  const text = decodeFeed(new Uint8Array(await response.arrayBuffer()));
  const feeds = new Map<string, string[]>();
  for (const line of text.split("\n")) {
    const match = line.match(/var hq_str_([^=]+)="([^"]*)"/);
    if (match) feeds.set(match[1], splitFields(match[2]));
  }
  if (feeds.size === 0) throw new Error("quote_empty");

  const groups: MarketGroup[] = GROUPS.map((spec) => {
    const items: MarketQuote[] = spec.items.map((item) => {
      const fields = feeds.get(item.feed) ?? [];
      return {
        secid: item.feed,
        code: symbolOf(item.feed),
        name: item.name,
        unit: item.unit,
        ...parseQuote(item, fields),
      };
    });
    return { id: spec.id, label: spec.label, blurb: spec.blurb, items };
  });

  const priced = groups.flatMap((group) => group.items).filter((item) => item.price !== null);
  if (priced.length === 0) throw new Error("market_unavailable");

  const asOf = Date.now();
  return {
    asOf,
    fetchedAt: new Date(asOf).toISOString(),
    source: "sina",
    stale: false,
    session: sessionInfo(new Date(asOf)),
    groups,
  };
}

let cache: { payload: MarketPayload; at: number } | null = null;
let inflight: Promise<MarketPayload> | null = null;

export async function loadMarket(): Promise<MarketPayload> {
  const now = Date.now();
  if (cache && now - cache.at < TTL_MS) return { ...cache.payload, stale: false };
  if (inflight) return inflight;

  inflight = (async () => {
    try {
      const payload = await fetchMarket();
      cache = { payload, at: Date.now() };
      return payload;
    } catch (error) {
      if (cache) {
        return { ...cache.payload, stale: true, session: sessionInfo() };
      }
      throw error;
    } finally {
      inflight = null;
    }
  })();

  return inflight;
}
