// 217之家 · 麻将规则单测
// 运行：node --test functionDirectory/mahjong_test.ts
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  advance,
  createTable,
  discard,
  evaluateWin,
  gang,
  huSelf,
  joinTable,
  leaveTable,
  publicTable,
  respondClaim,
  setMode,
  sortTiles,
  tileName,
  startNextHand,
  type MahjongMeld,
  type MahjongState,
} from "./mahjong.ts";

const IDS = ["a", "b", "c", "d"];

function seated(now = 0): MahjongState {
  const state = createTable();
  for (const id of IDS) joinTable(state, id, `住户${id}`, now);
  return state;
}

/** 把一局摆成确定的样子：手牌、牌墙、轮到 0 号位出牌 */
function rig(state: MahjongState, hands: string[][], wall: string[] = []): MahjongState {
  hands.forEach((hand, index) => {
    const seat = state.seats[index]!;
    seat.hand = sortTiles(hand);
    seat.melds = [];
    seat.discards = [];
    seat.lastAction = "";
  });
  state.phase = "playing";
  state.dealer = 0;
  state.turn = 0;
  state.wall = [...wall];
  state.drawn = hands[0][hands[0].length - 1] ?? null;
  state.justDrew = true;
  state.claim = null;
  state.lastDiscard = null;
  state.result = null;
  state.deadline = 30_000;
  return state;
}

const JUNK_1 = ["2m", "3m", "5m", "5m", "7m", "8m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"];
const JUNK_2 = ["1m", "3m", "5m", "7m", "9m", "1s", "1s", "4s", "6s", "8s", "9s", "6p", "8p"];
const JUNK_3 = ["2m", "4m", "6m", "8m", "1s", "3s", "5s", "7s", "9s", "1p", "5p", "7p", "9p"];
const P0 = ["1p", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "5p", "5p"];

test("胡牌判断：普通四面子一将", () => {
  const hand = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1s", "1s", "1s", "2p", "2p"];
  const win = evaluateWin(hand, []);
  assert.ok(win);
  assert.deepEqual(win!.fans, ["门清"]);
  assert.equal(win!.points, 2);
});

test("胡牌判断：七对与门清", () => {
  const hand = ["1m", "1m", "2m", "2m", "3m", "3m", "4s", "4s", "5s", "5s", "6p", "6p", "7p", "7p"];
  const win = evaluateWin(hand, []);
  assert.ok(win);
  assert.ok(win!.fans.includes("七对"));
  assert.equal(win!.points, 3);
});

test("胡牌判断：碰碰胡", () => {
  const hand = ["1m", "1m", "1m", "2m", "2m", "2m", "3s", "3s", "3s", "4p", "4p", "4p", "5p", "5p"];
  const win = evaluateWin(hand, []);
  assert.ok(win);
  assert.ok(win!.fans.includes("碰碰胡"));
});

test("胡牌判断：清一色", () => {
  const hand = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1m", "2m", "3m", "9m", "9m"];
  const win = evaluateWin(hand, []);
  assert.ok(win);
  assert.ok(win!.fans.includes("清一色"));
});

test("胡牌判断：差一张不算胡", () => {
  const hand = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1s", "1s", "2s", "2p", "3p"];
  assert.equal(evaluateWin(hand, []), null);
});

test("胡牌判断：碰过之后面子数要对得上", () => {
  const melds: MahjongMeld[] = [{ kind: "peng", tiles: ["1s", "1s", "1s"], from: 1 }];
  const good = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "2p", "2p"];
  assert.ok(evaluateWin(good, melds));
  const extra = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1m", "2m", "2p", "2p"];
  assert.equal(evaluateWin(extra, melds), null);
});

test("开局：四家入座自动发牌，庄家 14 张", () => {
  const state = createTable();
  joinTable(state, "a", "阿岚", 0);
  joinTable(state, "b", "小满", 0);
  joinTable(state, "c", "青禾", 0);
  assert.equal(state.phase, "waiting");
  assert.equal(state.handNo, 0);
  joinTable(state, "d", "中秋", 0);
  assert.equal(state.phase, "playing");
  assert.equal(state.handNo, 1);
  assert.equal(state.dealer, 0);
  assert.equal(state.turn, 0);
  assert.equal(state.seats[0]!.hand.length, 14);
  assert.equal(state.seats[1]!.hand.length, 13);
  assert.equal(state.wall.length, 108 - 53);
  assert.ok(state.seats[0]!.hand.includes(state.drawn!));
});

test("出牌：没人能要，下家摸牌", () => {
  const state = rig(seated(), [P0, JUNK_1, JUNK_2, JUNK_3], ["9m", "9s"]);
  discard(state, "a", "1p", 0);
  assert.equal(state.claim, null);
  assert.equal(state.turn, 1);
  assert.equal(state.seats[0]!.hand.length, 13);
  assert.equal(state.seats[0]!.discards.at(-1), "1p");
  assert.equal(state.seats[1]!.hand.length, 14);
  assert.equal(state.wall.length, 1);
  assert.equal(state.justDrew, true);
});

test("吃：只有下家能吃", () => {
  const state = rig(
    seated(),
    [["1m", "1m", "4m", "5m", "6m", "7m", "9m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"], ["2m", "3m", "5m", "5m", "7m", "8m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"], ["2m", "3m", "5m", "7m", "9m", "1s", "1s", "4s", "6s", "8s", "9s", "6p", "8p"], JUNK_3],
    ["9m"],
  );
  discard(state, "a", "1m", 0);
  assert.ok(state.claim);
  assert.deepEqual(Object.keys(state.claim!.options).sort(), ["b"]);
  assert.deepEqual(state.claim!.options["b"].chi, [["2m", "3m"]]);
  respondClaim(state, "b", "chi", ["3m", "2m"], 0);
  const seatB = state.seats[1]!;
  assert.equal(seatB.melds.length, 1);
  assert.deepEqual(seatB.melds[0].tiles, ["1m", "2m", "3m"]);
  assert.equal(seatB.hand.length, 11);
  assert.equal(state.turn, 1);
  assert.equal(state.phase, "playing");
});

test("碰：两家都能碰时，离出牌者最近的那家拿到", () => {
  const state = rig(
    seated(),
    [["5p", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "9p", "9p"], ["5p", "5p", "2m", "3m", "4m", "6m", "7m", "1s", "3s", "5s", "7s", "9s", "2p"], ["5p", "5p", "1m", "3m", "5m", "7m", "1s", "1s", "4s", "6s", "8s", "6p", "8p"], JUNK_3],
    ["9m"],
  );
  discard(state, "a", "5p", 0);
  assert.deepEqual(Object.keys(state.claim!.options).sort(), ["b", "c"]);
  respondClaim(state, "c", "peng", undefined, 0);
  respondClaim(state, "b", "peng", undefined, 0);
  assert.equal(state.seats[1]!.melds.length, 1);
  assert.equal(state.seats[2]!.melds.length, 0);
  assert.equal(state.turn, 1);
  assert.equal(state.claim, null);
});

test("胡：点炮优先于碰，放炮者付三份", () => {
  const seat0 = ["9s", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "4p", "5p"];
  const seat1 = ["9s", "9s", "2m", "3m", "4m", "6m", "7m", "1s", "3s", "5s", "7s", "2p", "4p"];
  const seat2 = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1s", "2s", "3s", "9s"];
  const state = rig(seated(), [seat0, seat1, seat2, JUNK_3], ["9m", "9m"]);
  const before = state.seats.map((seat) => seat!.score);
  discard(state, "a", "9s", 0);
  assert.equal(state.claim!.options["b"].peng, true);
  assert.equal(state.claim!.options["c"].hu, true);
  respondClaim(state, "b", "peng", undefined, 0);
  respondClaim(state, "c", "hu", undefined, 0);
  assert.equal(state.phase, "result");
  assert.equal(state.result!.winnerSeat, 2);
  assert.equal(state.result!.selfDraw, false);
  assert.equal(state.result!.fromSeat, 0);
  const points = state.result!.points;
  assert.ok(points >= 2);
  assert.equal(state.seats[2]!.score, before[2] + points * 3);
  assert.equal(state.seats[0]!.score, before[0] - points * 3);
  assert.equal(state.seats[1]!.score, before[1]);
});

test("自摸：三家各付一份", () => {
  const winning = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1s", "2s", "3s", "5p", "5p"];
  const state = rig(seated(), [winning, JUNK_1, JUNK_2, JUNK_3], ["9m"]);
  const before = state.seats.map((seat) => seat!.score);
  huSelf(state, "a", 0);
  assert.equal(state.phase, "result");
  assert.equal(state.result!.selfDraw, true);
  const points = state.result!.points;
  assert.equal(points, 2);
  assert.equal(state.seats[0]!.score, before[0] + points * 3);
  for (const index of [1, 2, 3]) {
    assert.equal(state.seats[index]!.score, before[index] - points);
    assert.equal(state.seats[index]!.hand.length, 13);
  }
  assert.equal(state.dealer, 0);
  assert.deepEqual(publicTable(state, "b").result!.hand.length, 14);
});

test("暗杠：补一张回来，手牌数量守恒", () => {
  const state = rig(
    seated(),
    [["5p", "5p", "5p", "5p", "1m", "2m", "3m", "4m", "6m", "7m", "1s", "3s", "9s", "9s"], JUNK_1, JUNK_2, JUNK_3],
    ["9m", "8m"],
  );
  gang(state, "a", "5p", 0);
  const seat = state.seats[0]!;
  assert.equal(seat.melds.length, 1);
  assert.equal(seat.melds[0].kind, "angang");
  assert.equal(seat.hand.length, 11);
  assert.equal(state.wall.length, 1);
  assert.equal(state.turn, 0);
  assert.equal(state.justDrew, true);
});

test("超时：自动打出刚摸的牌并轮转", () => {
  const state = rig(seated(), [P0, JUNK_1, JUNK_2, JUNK_3], ["9m", "9s"]);
  state.deadline = 0;
  advance(state, 1);
  assert.equal(state.turn, 1);
  assert.equal(state.seats[0]!.discards.length, 1);
});

test("牌墙摸完：荒庄不输不赢", () => {
  const state = rig(seated(), [P0, JUNK_1, JUNK_2, JUNK_3], []);
  const before = state.seats.map((seat) => seat!.score);
  discard(state, "a", "1p", 0);
  assert.equal(state.phase, "result");
  assert.equal(state.result!.draw, true);
  assert.deepEqual(state.seats.map((seat) => seat!.score), before);
});

test("离开：牌局作废，座位空出来", () => {
  const state = rig(seated(), [P0, JUNK_1, JUNK_2, JUNK_3], ["9m"]);
  leaveTable(state, "c", 0);
  assert.equal(state.phase, "waiting");
  assert.equal(state.seats[2], null);
  assert.equal(state.seats[0]!.hand.length, 0);
});

test("人不够不能开局", () => {
  const state = createTable();
  joinTable(state, "a", "阿岚", 0);
  joinTable(state, "b", "小满", 0);
  joinTable(state, "c", "青禾", 0);
  assert.throws(() => startNextHand(state, "a", 0), /need_four_players/);
});

test("视图：别人手牌只给张数，自己手牌可见", () => {
  const state = rig(seated(), [P0, JUNK_1, JUNK_2, JUNK_3], ["9m"]);
  const view = publicTable(state, "b");
  assert.equal(view.seats[1]!.handCount, 13);
  assert.equal(view.seats[0]!.handCount, 14);
  assert.equal(view.viewer.hand.length, 13);
  assert.equal(view.viewer.seat, 1);
  assert.equal(view.viewer.isTurn, false);
  assert.equal("hand" in view.seats[0]!, false);
});

test("补杠：碰过的刻子加上第四张", () => {
  const state = rig(
    seated(),
    [["5p", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "9p", "9p"], JUNK_1, JUNK_2, JUNK_3],
    ["9s", "8s"],
  );
  state.seats[0]!.melds = [{ kind: "peng", tiles: ["5p", "5p", "5p"], from: 2 }];
  state.seats[0]!.hand = sortTiles(["5p", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s"]);
  gang(state, "a", "5p", 0);
  const meld = state.seats[0]!.melds[0];
  assert.equal(meld.kind, "gang");
  assert.equal(meld.tiles.length, 4);
  assert.equal(state.seats[0]!.hand.length, 10);
  assert.equal(state.wall.length, 1);
});

test("吃碰超时：没人回应就轮到下家", () => {
  const state = rig(
    seated(),
    [["5p", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "9p", "9p"], ["5p", "5p", "2m", "3m", "4m", "6m", "7m", "1s", "3s", "5s", "7s", "9s", "2p"], JUNK_2, JUNK_3],
    ["9m", "8m"],
  );
  discard(state, "a", "5p", 0);
  assert.ok(state.claim);
  advance(state, state.claim!.deadline + 1);
  assert.equal(state.claim, null);
  assert.equal(state.turn, 1);
  assert.equal(state.seats[1]!.melds.length, 0);
});

test("点炮：带副露也能胡，番型照算", () => {
  const state = rig(
    seated(),
    [["9s", "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "1s", "2s", "3s", "4p", "5p"], ["9s", "2m", "3m", "4m", "6m", "7m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"], JUNK_2, JUNK_3],
    ["9m"],
  );
  state.seats[2]!.melds = [{ kind: "peng", tiles: ["1s", "1s", "1s"], from: 1 }];
  state.seats[2]!.hand = sortTiles(["1m", "2m", "3m", "4m", "5m", "6m", "7p", "8p", "9p", "9s"]);
  discard(state, "a", "9s", 0);
  assert.equal(state.claim!.options["c"].hu, true);
  // b 也能碰，但胡优先
  respondClaim(state, "b", "pass", undefined, 0);
  respondClaim(state, "c", "hu", undefined, 0);
  assert.equal(state.result!.winnerSeat, 2);
  assert.equal(state.result!.melds.length, 1);
  assert.ok(state.result!.points >= 1);
});

test("结算后自动开下一局，胡牌者坐庄", () => {
  const winning = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1s", "2s", "3s", "5p", "5p"];
  const state = rig(seated(), [winning, JUNK_1, JUNK_2, JUNK_3], ["9m"]);
  huSelf(state, "a", 0);
  advance(state, state.deadline + 1);
  assert.equal(state.phase, "playing");
  assert.equal(state.handNo, 2);
  assert.equal(state.dealer, 0);
  assert.equal(state.wall.length, 55);
  assert.equal(state.seats[0]!.hand.length, 14);
  assert.equal(state.seats[0]!.discards.length, 0);
});

test("玩法：等待时能切，打牌中不能切", () => {
  const state = createTable();
  joinTable(state, "a", "阿岚", 0);
  joinTable(state, "b", "小满", 0);
  joinTable(state, "c", "青禾", 0);
  setMode(state, "a", "honors", 0);
  assert.equal(state.mode, "honors");
  assert.throws(() => setMode(state, "a", "nope", 0), /invalid_mode/);
  joinTable(state, "d", "中秋", 0);
  assert.equal(state.phase, "playing");
  assert.throws(() => setMode(state, "a", "nochi", 0), /hand_in_progress/);
});

test("玩法：带字牌是 136 张，起手后剩 83 张", () => {
  const state = createTable();
  joinTable(state, "a", "阿岚", 0);
  joinTable(state, "b", "小满", 0);
  joinTable(state, "c", "青禾", 0);
  setMode(state, "a", "honors", 0);
  joinTable(state, "d", "中秋", 0);
  assert.equal(state.phase, "playing");
  assert.equal(state.wall.length, 136 - 53);
  const all = state.seats.flatMap((seat) => seat?.hand ?? []);
  assert.ok(all.some((tile) => tile.endsWith("z")), "牌墙里应该有字牌");
});

test("玩法：字牌能胡，顺子不能拿字牌凑", () => {
  const honorWin = ["1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m", "1z", "1z", "1z", "5z", "5z"];
  const win = evaluateWin(honorWin, []);
  assert.ok(win);
  assert.equal(tileName("5z"), "中");

  const fakeRun = ["1z", "2z", "3z", "4m", "5m", "6m", "7m", "8m", "9m", "1p", "2p", "3p", "5s", "5s"];
  assert.equal(evaluateWin(fakeRun, []), null);
});

test("玩法：不吃模式下吃牌选项不出现", () => {
  const state = createTable();
  joinTable(state, "a", "阿岚", 0);
  joinTable(state, "b", "小满", 0);
  joinTable(state, "c", "青禾", 0);
  setMode(state, "a", "nochi", 0);
  joinTable(state, "d", "中秋", 0);
  rig(
    state,
    [["1m", "1m", "4m", "5m", "6m", "7m", "9m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"], ["2m", "3m", "5m", "5m", "7m", "8m", "1s", "3s", "5s", "7s", "9s", "2p", "4p"], JUNK_2, JUNK_3],
    ["9m", "8m"],
  );
  discard(state, "a", "1m", 0);
  assert.equal(state.claim, null);
  assert.equal(state.turn, 1);
});