# feat: 客厅麻将（4 人联机 · 108 张推倒胡）

## 摘要

给 217 之家加一张麻将桌：4 人联机、108 张数牌、吃碰杠胡、按番型结算积分。

- 服务端纯状态机 + `game_state` 版本号乐观并发，**无新增迁移、无新增依赖**。
- 前端沿用项目现有的「面板 + 轮询」模式，1.2 秒拉一次牌桌。
- 与「耍起日报」「217金融」互不影响：不同面板、不同路由、不同数据。

## 规则

- 108 张（万 / 条 / 筒 各 1-9 四张），4 人一桌，坐满自动开局，每人 1000 分，庄家 14 张。
- 吃只限下家；碰、明杠不限；自己回合可暗杠、补杠（杠后补一张）。
- 胡牌优先级：胡 > 杠 / 碰 > 吃；多家可胡取离出牌者最近的一家。
- 结算：`1 + 番型数`（门清 / 碰碰胡 / 清一色 / 七对各 +1）；自摸三家各付一份，点炮者付三份；胡牌者坐庄，荒庄庄家不变。
- 超时：30 秒不出牌自动打出刚摸的牌；8 秒不表态视为不要。

## 设计

- `functionDirectory/mahjong.ts`：纯状态机，时间由调用方传入，随机只出现在洗牌，方便单测与回放。
- `withMahjongState`：读 `game_state(key='mahjong')` → `advance()` → `mutate()` → `JSON.stringify` 比对 → 带 `version` 的条件更新，冲突最多重试 8 次；与扑克、八角笼同一套并发模型。
- `publicTable()`：本人拿到手牌、可胡、可杠、可吃碰选项；他人只有手牌张数、副露与牌河。
- 断线/超时全部由服务端 `advance()` 推进，不依赖某个客户端在线。

## 接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/games/mahjong/state` | 轮询牌桌（240 次/分） |
| POST | `/games/mahjong/join` | 入座，第 4 位自动开局 |
| POST | `/games/mahjong/leave` | 离桌；牌局进行中则本局作废 |
| POST | `/games/mahjong/start` | 结算后手动开下一局 |
| POST | `/games/mahjong/action` | `discard` / `gang` / `hu` / `peng` / `chi` / `pass` |

全部位于 `requireMember` 之后，未登录返回 401。

## 改动文件

新增：

- `functionDirectory/mahjong.ts`
- `functionDirectory/mahjong_test.ts`
- `src/features/games/MahjongModal.tsx`

修改：

- `functionDirectory/app.ts`（import + 5 个处理器 + 5 条路由）
- `src/App.tsx`（`PanelKind` 增加 `mahjong`、dock 入口、面板渲染）
- `src/app.css`（追加麻将样式段）
- `src/net/types.ts` / `src/net/api.ts`（牌桌类型与 8 个方法、9 条错误文案）
- `package.json` / `.github/workflows/ci.yml` / `README.md`

## 测试与验证

```sh
npm test        # 22 项规则单测
npm run build   # tsc --noEmit + vite build
```

已跑过：

- `npm test` → 22 项全部通过。覆盖：胡牌判定（普通 / 七对 / 碰碰胡 / 清一色 / 面子数对不上）、吃只限下家、多家人抢碰的座次、点炮优先于碰、自摸与点炮结算、暗杠 / 补杠、超时自动出牌、荒庄、结算后自动开下一局、视图不泄露手牌。
- `tsc --noEmit` 前端与 `functionDirectory/` 均无报错。
- `vite build` → 51 modules，CSS 220.60 kB、JS 357.24 kB。
- 内存库 HTTP 冒烟 12 项通过，并确认 `/market/quotes` 路由未受影响。

## 风险与回滚

- 只新增 `game_state` 里 `key = 'mahjong'` 的一行；删掉该行即可重置牌桌，扑克与八角笼不受影响。
- 无数据库结构变更，回滚代码即可，无需回滚迁移。
- 上线后若出现异常局面，`/games/mahjong/leave` 全员离桌会清空牌桌并回到等待。

## 检查清单

- [x] `npm test` 通过
- [x] `npm run build` 通过
- [x] 4 人开局 / 吃碰杠胡 / 超时 / 荒庄 / 结算后下一局 手动验证
- [x] 不影响 `/market/quotes` 与既有面板
- [ ] `package.json` 版本号改为 `0.2.0`
- [ ] 合并后按 `CHANGELOG.md` 打 tag
