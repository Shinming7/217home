# 217金融 · 更新包（M15）

适用于 [`Shinming7/217home`](https://github.com/Shinming7/217home)，**基线是当前 `main`：`9e1c239`（M14 之后）**。
补丁已经按这个基线重做过，直接叠在 M13 / M14 之上，不会回滚站长密匙和仓库整理。

## 包里有什么

| 文件 | 用途 |
| --- | --- |
| `RELEASE_NOTES.md` | GitHub Release 正文，可直接整篇粘贴 |
| `PULL_REQUEST.md` | 按仓库 `.github/PULL_REQUEST_TEMPLATE.md` 填好的 PR 描述 |
| `CHANGELOG.md` | 仓库已有更新日志，这里给的是「未发布」下要加的条目，**不要整份覆盖** |
| `217finance.patch` | 对 `9e1c239` 的 unified diff，14 个文件，`git apply` 直接可用 |
| `files/` | 同样 14 个文件（改后状态），不方便用 patch 时覆盖 |
| `SHA256SUMS.txt` | 校验和 |
| `stats.json` | 逐文件增删统计（机器可读） |

## 方式 A：git apply（推荐）

```sh
git clone https://github.com/Shinming7/217home.git
cd 217home
git checkout main
git pull --ff-only            # 确认 HEAD 是 9e1c239 之后

git apply --check 217finance.patch   # 干跑，应该没有任何输出
git apply 217finance.patch

git add -A
git commit -m "feat(M15): 新增 217金融 实时行情终端"
git push origin main
```

> 如果 `main` 又往前走了，先 rebase；冲突大概率只出现在 `src/App.tsx`、`src/app.css`、`src/net/api.ts`、`README.md`。

## 方式 B：直接覆盖

```sh
cp -r <更新包>/files/. .
```

Windows 下把 `files` 里的 `functionDirectory`、`src` 两个目录，以及根目录的 `README.md`、`package.json`、`vite.config.ts` 一起复制到仓库根目录覆盖。

## 方式 C：网页上传（不装 git）

1. 打开 https://github.com/Shinming7/217home
2. **Add file → Upload files**
3. 把 `files/` 里的 `functionDirectory`、`src` 文件夹和根目录三个文件拖进去（拖文件夹会保留路径）
4. Commit 到 `main`，提交信息用 `feat(M15): 新增 217金融 实时行情终端`

## 验证

```sh
npm ci
npm run build            # tsc + 生产构建
npm run check:function   # deno check（需要 Deno 2）

npm run dev:mock         # 终端 1，8000 端口，需要能访问 hq.sinajs.cn
npm run dev              # 终端 2，5173
```

打开 `http://127.0.0.1:5173`，进站后点底部 **217金融**：
四组数据都应有价格，10 秒后自动变化（休市时段价格不变属正常）。书桌 CRT 悬停会提示「点击看 217 金融」。

## 回滚

```sh
git apply -R 217finance.patch
# 或
git revert <commit>
```

## 发布到 GitHub 的建议步骤

1. 应用补丁，提交并推到 `main`（或开 PR，正文用 `PULL_REQUEST.md`）
2. 把 `CHANGELOG.md` 里「未发布」那段加进仓库的 `CHANGELOG.md`
3. 可选：`git tag m15 && git push origin m15`
4. Releases 新建 `m15`，标题「M15 · 217金融：小屋里的实时行情终端」，正文粘贴 `RELEASE_NOTES.md`
5. 附件传这个 zip（或只传 `217finance.patch`）

## 备注

- 生产环境（Qoder Sites 云函数）需要允许出站访问 `hq.sinajs.cn`
- 没有数据库迁移，不用跑 SQL
- 本地 `dev:mock` 的网络权限已写进 `package.json`
