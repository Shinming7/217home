# M15 · 217金融：小屋里的实时行情终端

> 小屋的书桌上多了一台亮着绿字的老式 CRT：美股、全球指数、商品期货、航运运价，每 10 秒刷新一次。

- **版本**：M15（基于 `main@9e1c239`，叠加在 M13 / M14 之上）
- **类型**：新功能（feature）
- **影响面**：前端房间 + 云函数 + 本地模拟后端
- **数据影响**：无 schema 变更，不改动任何线上数据

---

## 亮点

- **两个入口**：底部功能条新增绿色的 **217金融** 按钮；房间书桌上的 CRT 也能点，悬停提示「点击看 217 金融」
- **30 个实时标的**：9 个指数、10 只美股、10 个商品期货、1 个集运运价
- **像素 CRT 面板**：扫描线、绿色磷光、红涨绿跌、顶部行情跑马灯、每行一条客户端自绘的迷你走势线
- **A股 / 美股双时段徽章**：分别按 `Asia/Shanghai` 与 `America/New_York` 判断盘中/盘前/已收盘，夏令时自动切换
- **不会打爆上游**：服务端 6 秒缓存 + 请求合并，前端 10 秒轮询，切到后台自动暂停
- **断网不空白**：上游失败时回退到最后一份成功数据并标记「缓存数据」，完全拿不到才报错

---

## 行情覆盖

| 分组 | 标的 | 数量 |
| --- | --- | --- |
| 大盘指数 | 标普500、纳斯达克、道琼斯、恒生指数、上证指数、深证成指、创业板指、沪深300、科创50 | 9 |
| 美股 | 英伟达、苹果、微软、谷歌、亚马逊、Meta、特斯拉、博通、礼来、摩根大通 | 10 |
| 商品期货 | COMEX 黄金/白银/原油/铜、沪金、沪银、沪铜、螺纹钢、铁矿石、豆粕（主连） | 10 |
| 航运运价 | 欧线集运主连 | 1 |

数据来自新浪财经公开行情接口 `hq.sinajs.cn`（无需密钥，需带 `Referer`），一次请求取回全部标的。

---

## 交互细节

- 行悬停显示开 / 高 / 低 / 昨收 / 成交额
- 每 10 秒自动刷新，按钮上带倒计时，可手动立即刷新
- 页面切到后台（`document.hidden`）时暂停轮询，回来继续
- 走势线最多保留最近 40 个采样点，刚打开面板时为空，两次刷新后出现
- 收市后展示最近一次收盘价，商品夜盘时段仍会跳动

---

## 技术实现

### 后端

- 新增 `functionDirectory/market.ts`
  - 标的目录（feed → 名称 → 单位 → 字段格式）集中在一处
  - 按 5 类字段格式解析新浪返回的 GBK 文本：沪深 / 港股 / 美股 / 外盘期货 / 国内商品
  - 涨跌额、涨跌幅分别按昨收（股票、外盘）或昨结算（国内商品）计算
  - 6 秒 TTL 缓存 + in-flight 去重；失败回退缓存并置 `stale`
  - A股、美股两个时区分别判断开闭市
- `functionDirectory/app.ts` 新增 `GET /market/quotes`
  - 需要登录态（与其它接口一致），不影响现有路由
  - 每住户 30 次/分钟限流
  - 上游异常映射为 `market_unavailable`（503）

### 前端

- 新增 `src/features/finance/FinanceTerminal.tsx`
- `src/net/types.ts` 增加 `MarketQuote / MarketGroup / MarketSession / MarketPayload`
- `src/net/api.ts` 增加 `market()` 与 `market_unavailable` 文案
- `src/App.tsx` 接入面板与底部按钮（未改动 M13 的站长上任 / 退位逻辑）
- `src/game/{engine,roomArt,roomData}.ts` 增加书桌 CRT 的绘制、命中区域、悬停提示与点击回调
- `src/app.css` 追加 `.fin-*` 样式（344 行，含窄屏与 `prefers-reduced-motion` 适配）

### 配套调整

- `package.json`：`dev:mock` 的 Deno 权限放行 `hq.sinajs.cn`（本地模拟后端要取行情）
- `vite.config.ts`：watcher 忽略 `**/*.tmpdir/**` 等临时目录，避免编辑器「临时文件 + 重命名」落盘时把 dev server 崩掉

---

## 变更清单

新增 2 个文件，修改 12 个文件，共 **+1022 / −7** 行（基于 `main@9e1c239`）。

| 文件 | 变更 |
| --- | --- |
| `functionDirectory/market.ts` | 新增 · 行情目录、解析、缓存、时段判断（334 行） |
| `src/features/finance/FinanceTerminal.tsx` | 新增 · 行情终端面板（220 行） |
| `src/app.css` | +344 · `.fin-*` 全套样式 |
| `src/game/engine.ts` | +37 · CRT 命中、悬停、点击、提示 |
| `src/net/types.ts` | +41 · 行情类型 |
| `functionDirectory/app.ts` | +9 · `/market/quotes` 路由 |
| `src/game/roomArt.ts` | +9/−3 · 书桌 CRT 像素画 |
| `src/App.tsx` | +8/−2 · 面板与按钮接入 |
| `src/game/roomData.ts` | +2 · CRT 坐标常量 |
| `src/features/room/RoomCanvas.tsx` | +5 · 透传 `onOpenFinance` |
| `src/net/api.ts` | +3 · 接口与错误文案 |
| `README.md` | +3 · 功能与数据源说明 |
| `package.json` | +1/−1 · `dev:mock` 网络权限 |
| `vite.config.ts` | +6/−1 · watcher 忽略临时目录 |

---

## 部署 / 验证

1. 应用补丁（或直接覆盖文件），见包内 `README.md`
2. 本地：

   ```sh
   npm ci
   npm run dev:mock   # 8000，需能访问 hq.sinajs.cn
   npm run dev        # 5173
   ```

3. 云函数需要允许出站访问 `hq.sinajs.cn`；无数据库迁移
4. 首次打开面板会立即请求一次，随后每 10 秒一次

验证结果：

- `npm run build`：tsc 类型检查 + Vite 生产构建通过（49 modules）
- `npm run check:function`：`deno check` 通过（app.ts / market.ts / mock-backend.ts）
- 接口实测（本地 mock 后端）：未登录 401；登录后 200，四组 9 / 10 / 10 / 1 条全部有价；6 秒内重复请求命中缓存
- 补丁自检：应用到 `9e1c239` 的干净副本，14 个文件逐字节与发布内容一致

**回滚**：`git apply -R 217finance.patch`，或 `git revert <commit>`。

---

## 已知限制

- 只用了新浪一个数据源；新浪没有波罗的海 BDI，所以航运只有集运欧线一条
- 没有 K 线、分时和自选列表，只做「一眼看行情」
- 行情为公开接口转发，可能有秒级延迟，**仅供参考，不构成投资建议**
- 节假日休市按周末规则简化处理（工作日节日会显示盘中，但价格不动）
